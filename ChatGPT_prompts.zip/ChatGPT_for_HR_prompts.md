# ChatGPT for HR - 人力资源团队提示词集合

> 来源：OpenAI Academy
> 标题：ChatGPT for HR
> 描述：为 HR 和人员运营提供即用型提示词，涵盖招聘、员工参与、政策制定、合规研究和员工沟通
> 最后更新：2025年8月12日

## 概述

HR 团队是员工体验和运营一致的骨干。ChatGPT 可以帮助 HR 团队通过创建政策初稿、回答员工问题、总结调查反馈和生成内部沟通内容来节省时间。

---

## 一、工作场所体验与反馈 (Workspace Experience and Feedback)

ChatGPT 帮助 HR 团队探索员工反馈、趋势和报告，以指导项目并改善工作场所体验。

| 使用场景 | 提示词 |
|---------|--------|
| **起草员工调查问题** | Write 6–8 employee survey questions designed to measure [e.g. belonging, manager trust, workload balance]. Ensure the questions are neutral and easy to understand. Format them as one question per line with rating scale suggestions.<br><br>**中文版**：编写6-8个旨在衡量[例如：归属感、管理者信任、工作平衡]的员工调查问题。确保问题中立且易于理解。格式为每行一个问题，并附有评分量表建议。 |
| **生成绩效评估提示** | Develop a set of five questions for performance reviews that encourage reflection, future goal setting, and actionable feedback. Tailor to [function/team], and keep the tone constructive and growth-oriented. Present the questions as a list for a review form.<br><br>**中文版**：开发五个用于绩效评估的问题，鼓励反思、未来目标设定和可操作的反馈。针对[职能/团队]定制，保持建设性和成长导向的语气。将问题作为评估表格的列表呈现。 |
| **分析离职调查主题** | Review the following employee exit survey responses and identify the top recurring themes, concerns, and sentiment trends. These responses are from [department/timeframe]. Provide a thematic summary with bullet points and representative quotes. [Insert responses here]<br><br>**中文版**：审查以下员工离职调查回复并识别最重复的主题、关注点和情绪趋势。这些回复来自[部门/时间段]。提供带有要点和代表性引用的主题摘要。 |
| **分析员工流失趋势** | Analyze this employee attrition dataset from the last 12 months. Focus on patterns by department, tenure, and exit reasons. Summarize key insights and suggest 2–3 actions HR should consider. Present findings as bullet points followed by a short paragraph. [Upload your CSV or paste table here]<br><br>**中文版**：分析过去12个月的员工流失数据集。关注按部门、任期和离职原因的模式。总结关键洞察并建议 HR 应考虑的2-3项行动。以要点后跟简短段落的形式呈现发现。 |
| **生成薪酬基准报告** | Based on this internal salary data and industry benchmarks, highlight pay discrepancies by role, gender, and level. Include averages, standard deviation, and a visual if possible. Provide a short summary for leadership review. [Upload benchmark and internal files]<br><br>**中文版**：基于此内部薪资数据和行业基准，突出按角色、性别和级别的薪酬差异。包括平均值、标准差和可能的可视化。为领导审查提供简短摘要。 |

---

## 二、HR研究与合规 (HR Research & Compliance)

ChatGPT 帮助分析 HR 趋势、基准和行业数据以指导政策和规划。**使用深度研究和网络搜索获取实时洞察。**

| 使用场景 | 提示词 |
|---------|--------|
| **研究全球HR合规更新** | Research the latest 2024–2025 HR compliance changes in the EU, US, and APAC (focus on remote work laws, employee classification, and data privacy). Provide links to official sources and summarize in plain language. Present findings in a 3-region comparison table with a 1-paragraph summary per region.<br><br>**中文版**：研究欧盟、美国和亚太地区最新的2024-2025年 HR 合规变更（关注远程工作法、员工分类和数据隐私）。提供官方来源链接并用通俗语言总结。在3区域比较表中呈现发现，每个区域附一段摘要。 |
| **基准DEI预算** | Research typical DEI program budgets and team sizes for companies with 500–5,000 employees in the US. Include industry benchmarks if available. Present key insights with 3 cited data points and include a simple bullet summary for leadership.<br><br>**中文版**：研究员工人数在500-5000人的美国公司的典型 DEI 项目预算和团队规模。如果可能，包括行业基准。用3个引用数据点呈现关键洞察，并为领导层提供简单的要点摘要。 |
| **探索2025年HR技术趋势** | [You're briefing HR leadership on tech trends.] Research and summarize the top 5 HR technology trends expected to shape 2025. Include use cases, vendor examples, and implications for mid-sized companies. Synthesize insights into a short executive briefing with citations and actionable recommendations.<br><br>**中文版**：[您正在向HR领导层介绍技术趋势。]研究和总结预计将塑造2025年的前5大HR技术趋势。包括用例、供应商示例和对中型公司的影响。将洞察综合成简短的高管简报，附引用和可操作建议。 |
| **比较跨行业员工留存策略** | [You are building a retention initiative for a mid-sized tech firm.] Research 3 innovative, high-impact employee retention strategies used in tech, healthcare, and financial services. Focus on post-pandemic engagement challenges. Include cited examples and summarize key elements in a side-by-side comparison chart.<br><br>**中文版**：[您正在为中型科技公司建立留任计划。]研究科技、医疗保健和金融服务中使用的3种创新、高影响力的员工留存策略。关注疫情后的参与挑战。包括引用示例并在并排比较图表中总结关键要素。 |
| **研究招聘工具** | Research 4 top-rated candidate screening or sourcing tools used by mid-market companies. Summarize features, pricing, compliance status (EEOC), and known limitations. Provide links to primary sources and present findings in a comparison table.<br><br>**中文版**：研究中型市场公司使用的4个顶级候选人筛选或采购工具。总结功能、定价、合规状态（EEOC）和已知限制。提供主要来源链接并在比较表中呈现发现。 |

---

## 三、人才获取与员工参与 (Talent Acquisition & Employee Engagement)

ChatGPT 指导招聘流程、参与规划和员工沟通。

| 使用场景 | 提示词 |
|---------|--------|
| **创建面试问题** | Develop behavioral interview questions aligned to our company values for a [role title] opening in [team/department]. We want to assess both technical skills and culture fit. Provide 6–8 questions grouped by competency.<br><br>**中文版**：制定符合我们公司价值观的行为面试问题，用于[团队/部门]的[职位]空缺。我们希望评估技术技能和文化契合度。提供6-8个按能力分组的问题。 |
| **编写职位描述草稿** | Based on this information [insert job responsibilities, skills, team context], write a professional job description for a [job title]. Include a short intro, responsibilities, required qualifications, and what makes the role appealing.<br><br>**中文版**：基于此信息[插入工作职责、技能、团队背景]，为[职位]编写专业职位描述。包括简短介绍、职责、所需资格以及该职位的吸引力。 |
| **头脑风暴参与计划** | Generate five practical ideas for improving employee engagement across [company/team/region]. Consider our hybrid work model, current engagement scores, and time/resource constraints. Present each idea with a short description, expected impact, and implementation effort level.<br><br>**中文版**：生成5个提高[公司/团队/区域]员工参与度的实用想法。考虑我们的混合工作模式、当前参与度分数以及时间/资源限制。用简短描述、预期影响和实施工作量级别呈现每个想法。 |
| **编写内部认可简介** | Draft a short recognition message to celebrate [employee/team] for their recent accomplishment: [describe what they did]. Write it in a warm, appreciative tone suitable for Slack or email. Keep it under 100 words.<br><br>**中文版**：起草简短的认可信息，以庆祝[员工/团队]的最近成就：[描述他们做了什么]。以温暖、感激的语气撰写，适合 Slack 或电子邮件。保持在100字以内。 |
| **创建DEI工作坊大纲** | Design a one-hour DEI workshop for employees at [company/team]. The goal is to foster inclusive communication and awareness. Include an agenda, key learning objectives, interactive activities, and 2–3 discussion questions.<br><br>**中文版**：为[公司/团队]的员工设计一小时的 DEI 工作坊。目标是促进包容性沟通和意识。包括议程、关键学习目标、互动活动和2-3个讨论问题。 |

---

## 四、政策与项目制定 (Policy & Program Development)

ChatGPT 帮助制定清晰的内部沟通、入职计划和福利计划。

| 使用场景 | 提示词 |
|---------|--------|
| **起草内部政策摘要** | Summarize the key points of this [internal policy or handbook section] so HR business partners can understand and communicate it effectively. This policy relates to [brief description or context]. Present the summary in clear, professional language under 200 words.<br><br>**中文版**：总结此[内部政策或手册章节]的关键点，以便 HR 业务合作伙伴能够理解并有效沟通。此政策涉及[简要描述或背景]。以清晰、专业的语言呈现摘要，控制在200字以内。 |
| **起草复工FAQ** | Write an employee-facing FAQ to support our return-to-office transition. Use this background information [insert key RTO plan details]. Cover top employee concerns (e.g. hybrid schedules, health protocols, expectations) in a warm and clear tone. Include 5–7 questions with answers.<br><br>**中文版**：编写面向员工的 FAQ 以支持我们的复工过渡。使用此背景信息[插入关键复工计划详情]。以温暖清晰的语气涵盖员工最关心的问题（例如：混合时间表、健康协议、期望）。包括5-7个问题及答案。 |
| **规划入职周** | Build a 5-day onboarding schedule for new hires in [department or region]. Include orientation goals, topics to cover, people to meet, and relevant tools or resources. Present it in a simple day-by-day table with time blocks if helpful.<br><br>**中文版**：为[部门或区域]的新员工建立5天入职计划。包括入职目标、涵盖主题、会面人员以及相关工具或资源。以简单的逐日表格呈现，如有帮助可包含时间段。 |
| **头脑风暴福利计划** | Suggest three tailored wellbeing programs for employees at [company/team], considering recent feedback and budget constraints. Include rationale, estimated costs, and potential success metrics. Present ideas as a short proposal summary.<br><br>**中文版**：为[公司/团队]的员工建议3个定制的福利计划，考虑最近的反馈和预算限制。包括理由、预估成本和潜在成功指标。作为简短提案摘要呈现想法。 |
| **规划合规培训推广** | Create a phased plan to roll out a new compliance training across [team/region]. Include timing, communications strategy, target audiences, and support materials. Present the plan in bullet points or as a 4-week calendar.<br><br>**中文版**：制定跨[团队/区域]推广新合规培训的分阶段计划。包括时间、沟通策略、目标受众和支持材料。以要点或4周日历形式呈现计划。 |

---

## 五、内部品牌视觉与沟通 (Internal Brand Visuals & Communication)

ChatGPT 创建 HR 视觉、横幅和内部品牌资产以提供精致的员工体验。

| 使用场景 | 提示词 |
|---------|--------|
| **创建入职欢迎横幅** | Create an image for a new employee onboarding welcome banner. Style: clean and modern. Mood: warm and inclusive. Format: horizontal banner with space for overlay text. Include visual cues like a diverse team, coffee cups, or digital collaboration tools.<br><br>**中文版**：创建新员工入职欢迎横幅图像。风格：简洁现代。情绪：温暖包容。格式：带覆盖文本空间的水平横幅。包括视觉提示，如多元化团队、咖啡杯或数字协作工具。 |
| **设计内部DEI海报** | Create a poster-style image for an internal DEI campaign. Style: bold, minimal. Include abstract representations of diversity (hands, overlapping shapes, color blocks). Mood: optimistic and forward-looking. Include placeholder space for a slogan or quote.<br><br>**中文版**：为内部 DEI 活动创建海报风格图像。风格：大胆极简。包括多样性的抽象表示（手、重叠形状、色块）。情绪：乐观前瞻。包括口号或引用的占位空间。 |
| **说明混合工作政策** | Generate an illustration showing a hybrid work scenario: a person working from home, a coworking space, and a modern office. Style: flat illustration or soft 3D. Intended for use in HR documentation.<br><br>**中文版**：生成展示混合工作场景的插图：在家工作的人、共享办公空间和现代办公室。风格：扁平插图或柔和 3D。旨在用于 HR 文档。 |
| **可视化员工生命周期** | Create a simple visual diagram of the employee lifecycle: attract, onboard, develop, retain, offboard. Use icons or abstract figures to represent each phase. Style: corporate presentation-ready.<br><br>**中文版**：创建员工生命周期的简单可视化图表：吸引、入职、发展、留任、离职。使用图标或抽象人物表示每个阶段。风格：企业演示就绪。 |

---

## 使用建议

### 推荐工具
- **深度研究**：用于合规和行业基准研究
- **网络搜索**：获取实时HR趋势洞察

### 最佳实践
1. 将方括号 `[...]` 中的内容替换为具体信息
2. 定期更新合规研究以反映最新法规
3. 保留成功的调查模板和职位描述
4. 根据公司文化调整沟通语气
5. 使用数据驱动方法制定HR决策

---

*文档生成时间：2025年8月*
*原文链接：https://academy.openai.com/public/clubs/work-users-ynjqu/resources/use-cases-hr*
