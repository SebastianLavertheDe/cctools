# ChatGPT for Any Role - Prompt Collection

> 来源：OpenAI Academy
> 标题：ChatGPT for any role
> 描述：学习任何角色的使用场景和提示词
> 更新时间：2025年8月7日

本文档整理了适用于各种工作角色的 ChatGPT 使用场景和提示词模板。

---

## 沟通与写作 (Communication & Writing)

ChatGPT 支持创建草稿、润色文案以及适应日常职场沟通。

| 使用场景 | 提示词 |
|---------|--------|
| **撰写专业邮件** | Write a professional email to [recipient]. The email is about [topic] and should be polite, clear, and concise. Provide a subject line and a short closing.<br><br>**中文版**：写一封致[收件人]的专业邮件。邮件关于[主题]，应礼貌、清晰且简洁。提供主题行和简短的结束语。 |
| **改写以提高清晰度** | Rewrite the following text so it is easier to understand. The text will be used in a professional setting. Ensure the tone is clear, respectful, and concise. Text: [paste text].<br><br>**中文版**：重写以下文字使其更易理解。文字将用于专业场合。确保语气清晰、尊重且简洁。文字：[粘贴文字]。 |
| **为受众调整信息** | Reframe this message for [audience type: executives, peers, or customers]. The message was originally written for [context]. Adjust tone, word choice, and style to fit the intended audience. Text: [paste text].<br><br>**中文版**：为[受众类型：高管、同事或客户]重新构建此信息。该信息最初是为[背景]撰写的。调整语气、措辞和风格以适应目标受众。文字：[粘贴文字]。 |
| **起草会议邀请** | Draft a meeting invitation for a session about [topic]. The meeting will include [attendees/roles] and should outline agenda items, goals, and preparation required. Provide the text in calendar-invite format.<br><br>**中文版**：起草一份关于[主题]的会议邀请。会议将包括[参会者/角色]，应概述议程项目、目标和所需准备。以日历邀请格式提供文本。 |
| **总结长邮件** | Summarize this email thread into a short recap. The thread includes several back-and-forth messages. Highlight key decisions, action items, and open questions. Email: [paste text].<br><br>**中文版**：将此邮件线程总结为简短回顾。线程包含多封来回消息。突出关键决策、行动项目和未决问题。邮件：[粘贴文字]。 |

---

## 会议与协作 (Meetings & Collaboration)

ChatGPT 帮助简化准备、记录和后续跟进工作。

| 使用场景 | 提示词 |
|---------|--------|
| **创建会议议程** | Create a structured agenda for a meeting about [topic]. The meeting will last [time] and include [attendees]. Break the agenda into sections with time estimates and goals for each section.<br><br>**中文版**：为关于[主题]的会议创建结构化议程。会议将持续[时间]，包括[参会者]。将议程分为若干部分，每部分包含时间估算和目标。 |
| **总结会议记录** | Summarize these meeting notes into a structured recap. The notes are rough and informal. Organize them into categories: key decisions, next steps, and responsibilities. Notes: [paste text].<br><br>**中文版**：将这些会议记录总结为结构化回顾。记录粗糙且非正式。将其组织为以下类别：关键决策、后续步骤和责任分工。记录：[粘贴文字]。 |
| **创建行动项目列表** | Turn the following meeting notes into a clean task list. The tasks should be grouped by owner and include deadlines if mentioned. Notes: [paste text].<br><br>**中文版**：将以下会议记录转换为清晰的任务列表。任务应按负责人分组，如果提到了截止日期，也应包含。记录：[粘贴文字]。 |
| **准备会议问题** | Suggest thoughtful questions to ask in a meeting about [topic]. The purpose of the meeting is [purpose]. Provide a list of at least 5 questions that show preparation and insight.<br><br>**中文版**：建议在关于[主题]的会议中提出的有见地的问题。会议的目的是[目的]。提供至少5个能体现准备和洞察力的问题。 |
| **起草后续邮件** | Write a professional follow-up email after a meeting about [topic]. Include a recap of key points, assigned responsibilities, and next steps with deadlines. Use a clear and polite tone.<br><br>**中文版**：写一封关于[主题]会议后的专业后续邮件。包括关键点回顾、分配的职责以及带截止日期的后续步骤。使用清晰礼貌的语气。 |

---

## 批判性思维与决策 (Critical Thinking & Decision Making)

ChatGPT 帮助分析问题、比较选项并做出明智决策。

| 使用场景 | 提示词 |
|---------|--------|
| **识别根本原因** | Analyze the following workplace issue: [describe issue]. The context is that the problem has occurred multiple times. Identify possible root causes and suggest questions to confirm them.<br><br>**中文版**：分析以下工作场所问题：[描述问题]。背景是此问题已发生多次。识别可能的根本原因，并建议确认这些问题。 |
| **比较选项** | Compare the following two or more possible solutions: [list options]. The decision needs to be made in [timeframe]. Evaluate pros, cons, and potential risks for each option.<br><br>**中文版**：比较以下两个或更多可能的解决方案：[列出选项]。需要在[时间框架]内做出决定。评估每个选项的利弊和潜在风险。 |
| **决策标准** | Help define clear decision-making criteria for [describe decision]. The context is that multiple stakeholders are involved. Provide a short list of weighted criteria to guide the choice.<br><br>**中文版**：帮助为[描述决策]定义明确的决策标准。背景是涉及多个利益相关者。提供一份简短的加权标准清单以指导选择。 |
| **风险评估** | Assess the potential risks of the following plan: [describe plan]. The plan is set to start on [date]. List risks by likelihood and impact, and suggest mitigation strategies.<br><br>**中文版**：评估以下计划的潜在风险：[描述计划]。计划定于[日期]开始。按可能性和影响列出风险，并建议缓解策略。 |
| **推荐最佳选项** | Based on the following background: [describe situation and options], recommend the most suitable option. Explain your reasoning clearly and suggest first steps for implementation.<br><br>**中文版**：基于以下背景：[描述情况和选项]，推荐最合适的选项。清晰解释你的推理，并建议实施的第一步。 |

---

## 组织与生产力 (Organization & Productivity)

ChatGPT 帮助构建任务、时间和优先级。

| 使用场景 | 提示词 |
|---------|--------|
| **记录每日优先事项** | Create a prioritized to-do list from the following tasks: [paste tasks]. The context is a typical workday with limited time. Suggest which tasks should be done first and why.<br><br>**中文版**：从以下任务创建优先级待办事项列表：[粘贴任务]。背景是时间有限的典型工作日。建议哪些任务应该先完成以及原因。 |
| **创建周计划** | Build a weekly work plan for [describe role or situation]. The week includes deadlines, meetings, and individual focus time. Provide a balanced schedule with recommended priorities.<br><br>**中文版**：为[描述角色或情况]构建周工作计划。这一周包括截止日期、会议和个人专注时间。提供平衡的时间表和推荐优先级。 |
| **总结长文档** | Summarize the following document into 5 key points and 3 recommended actions. The document is [type: report, plan, or notes]. Keep the summary concise and professional. Text: [paste document].<br><br>**中文版**：将以下文档总结为5个关键点和3个建议行动。文档是[类型：报告、计划或记录]。保持总结简洁专业。文字：[粘贴文档]。 |
| **头脑风暴解决方案** | Brainstorm potential solutions to the following workplace challenge: [describe challenge]. Provide at least 5 varied ideas, noting pros and cons for each.<br><br>**中文版**：针对以下工作场所挑战头脑风暴潜在的解决方案：[描述挑战]。提供至少5个不同的想法，并注明每个想法的利弊。 |
| **撰写项目更新** | Draft a short project update for stakeholders. The project is [describe project]. Include progress made, current blockers, and next steps. Write in a professional, concise style.<br><br>**中文版**：为利益相关者起草简短的项目更新。项目是[描述项目]。包括取得的进展、当前障碍和后续步骤。以专业简洁的风格撰写。 |

---

## 使用提示

1. 将方括号 `[...]` 中的内容替换为你的具体信息
2. 根据实际需求调整提示词的语气和详细程度
3. 可以连续追问以深化或细化结果
4. 建议使用 "Use Cases for Work GPT" 获取更多针对你角色的想法

---

*文档生成时间：2025年8月*
*原文链接：https://academy.openai.com/public/clubs/work-users-ynjqu/resources/chatgpt-for-any-role*
