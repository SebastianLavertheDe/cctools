# ChatGPT for Executives - 高管提示词集合

> 来源：OpenAI Academy
> 标题：ChatGPT for executives
> 描述：为高管提供即用型提示词，用于研究、分析、沟通和战略可视化，以推动明智决策和组织对齐
> 最后更新：2025年8月12日

## 概述

高管专注于设定战略方向、做出高风险决策并确保跨团队对齐。他们的时间有限，注意力被分散到许多方向，因此速度、清晰度和杠杆作用至关重要。ChatGPT 帮助高管穿透噪音，让领导者能够更快行动、保持更多知情并做出更敏锐的决策。

---

## 一、投资者与市场情报 (Investor & Market Intelligence)

ChatGPT 研究资本流动、估值、情绪和交易基准以指导高管和投资者决策。**使用深度研究获取更深入的实时洞察。**

| 使用场景 | 提示词 |
|---------|--------|
| **总结投资者趋势** | I'm preparing for our investor update. Research the latest funding and market trends in [industry]. Focus on valuation benchmarks, risk sentiment, and notable exits. Present in a concise brief with sources.<br><br>**中文版**：我正在准备我们的投资者更新。研究[行业]的最新融资和市场趋势。关注估值基准、风险情绪和著名退出。在简明简报中呈现并附带来源。 |
| **调查投资者情绪** | Research current investor sentiment for companies in the [industry] space. Pull insights from earnings calls, investor letters, and analyst notes. Focus on risk appetite, funding trends, and growth expectations. Provide a 1-page briefing with source links.<br><br>**中文版**：研究[行业]领域公司的当前投资者情绪。从财报电话会议、投资者信和分析师笔记中提取洞察。关注风险偏好、融资趋势和增长预期。提供1页简报并附源链接。 |
| **基准高管薪酬** | Conduct research on executive compensation benchmarks for [title, e.g. CFO] at [company size and industry]. Include total compensation breakdowns, geographic variations, and trends across public/private companies. Summarize in a 1-page brief with data tables and citations.<br><br>**中文版**：对[公司规模和行业]的[职位，例如：CFO]的高管薪酬基准进行研究。包括总薪酬细分、地区差异和上市/私营公司的趋势。在1页简报中总结，包含数据表格和引用。 |
| **评估行业M&A机会** | I'm evaluating M&A options in the [sector/vertical]. Research recent acquisitions (past 24 months), typical deal sizes, common targets, and integration outcomes. Provide company examples, risks, and strategic rationale. Format as an investor-style briefing.<br><br>**中文版**：我正在评估[部门/垂直领域]的 M&A 选项。研究最近的收购（过去24个月）、典型交易规模、常见目标和整合结果。提供公司示例、风险和战略理由。格式化为投资者风格简报。 |
| **评估行业未来趋势** | I'm an executive at [company/industry]. Conduct deep research on 3–5 emerging trends in [industry/topic] over the next 3 years. Include industry-specific examples, expert citations, and potential implications for strategy and talent planning. Present as an executive summary with bullet points and links to sources.<br><br>**中文版**：我是[公司/行业]的高管。对未来3年[行业/主题]的3-5个新兴趋势进行深入研究。包括行业特定示例、专家引用以及对战略和人才规划的潜在影响。作为高管摘要呈现，带要点和来源链接。 |

---

## 二、高管与组织沟通 (Executive & Organizational Communications)

ChatGPT 帮助制作清晰、针对受众的高管叙述和内部沟通资产以推动对齐和参与。**使用 Canvas 进行实时编辑。**

| 使用场景 | 提示词 |
|---------|--------|
| **起草愿景声明** | Help me draft a compelling vision statement for our [company/team/initiative]. Our focus areas are: [insert key goals, values, or direction]. Make it inspiring, concise, and easy to communicate across departments.<br><br>**中文版**：帮助我为我们的[公司/团队/计划]起草引人注目的愿景声明。我们的重点领域是：[插入关键目标、价值观或方向]。使其具有启发性、简洁且易于跨部门传达。 |
| **生成全员大会谈话要点** | I need talking points for an upcoming company-wide town hall. The theme is [insert theme or announcement]. Make it engaging, clear, and forward-looking. Limit to 5 minutes of content.<br><br>**中文版**：我需要即将举行的公司全员大会的谈话要点。主题是[插入主题或公告]。使其吸引人、清晰且前瞻。内容限制在5分钟内。 |
| **更新内部沟通策略** | Help me design a new internal communications plan for [company or team]. We're trying to improve alignment, morale, and transparency. Suggest 3 guiding principles and a simple comms calendar.<br><br>**中文版**：帮助我为[公司或团队]设计新的内部沟通计划。我们正在努力改善对齐、士气和透明度。建议3个指导原则和简单的沟通日历。 |
| **规划重组沟通序列** | I'm planning communications for a reorg. Provide a step-by-step message plan by audience type (execs, managers, all staff). Include tone guidelines and delivery format per message.<br><br>**中文版**：我正在为重组规划沟通。按受众类型（高管、管理者、全体员工）提供分步消息计划。包括每个消息的语气指南和传递格式。 |
| **起草继任计划备忘录** | Help me draft a succession planning memo for our [leadership team/board]. Include reasoning, timing, and a transparent outline of next steps for internal comms.<br><br>**中文版**：帮助我为我们的[领导团队/董事会]起草继任计划备忘录。包括理由、时机和内部沟通的透明后续步骤大纲。 |

---

## 三、战略规划与决策支持 (Strategic Planning & Decision Support)

ChatGPT 帮助制定多时间跨度战略和结构化比较以指导优先级排序和资源分配。**使用推理模型获取更多战略洞察。**

| 使用场景 | 提示词 |
|---------|--------|
| **创建定价策略简报** | We're revisiting our pricing strategy for [product/service]. Based on [insert context: goals, customer segments, competitive positioning], suggest 2–3 pricing models and pros/cons of each.<br><br>**中文版**：我们正在重新审视[产品/服务]的定价策略。基于[插入背景：目标、客户细分、竞争定位]，建议2-3种定价模型及每种模型的利弊。 |
| **优先排序增长杠杆** | Given our goals [insert business goals], identify 3 high-potential growth levers and estimate effort vs. impact. Include a table with short descriptions and trade-offs.<br><br>**中文版**：鉴于我们的目标[插入业务目标]，识别3个高潜力增长杠杆并估算工作量与影响力。包括带简短描述和权衡的表格。 |
| **分析市场进入风险** | We are considering entering [new market/region]. Based on current economic, legal, and competitive factors, summarize key risks and mitigation strategies in bullet format.<br><br>**中文版**：我们正在考虑进入[新市场/区域]。基于当前经济、法律和竞争因素，以要点格式总结关键风险和缓解策略。 |
| **重塑战略权衡** | We're choosing between [Option A] and [Option B] for our next big investment. Compare trade-offs across cost, time, team capacity, and customer impact. Recommend based on goal fit.<br><br>**中文版**：我们正在为下一个大投资在[选项 A]和[选项 B]之间做出选择。比较成本、时间、团队容量和客户影响的权衡。基于目标契合度推荐。 |
| **设计3年战略大纲** | Based on these business priorities [insert high-level goals], help me develop a high-level 3-year strategy. Include major focus areas, risks, and milestones per year.<br><br>**中文版**：基于这些业务优先级[插入高层目标]，帮助我制定高层3年战略。包括主要关注领域、风险和每年的里程碑。 |

---

## 四、分析绩效与数据洞察 (Analytical Performance & Data Insights)

ChatGPT 解释运营和财务数据集以发现趋势、诊断问题、预测结果并优化计划。

| 使用场景 | 提示词 |
|---------|--------|
| **识别表现优异和不佳的细分** | This is a dataset of performance across [regions/products/customers]. Identify which segments are over- and under-performing relative to the average. Show the metrics driving this and recommend 2 actions based on the findings.<br><br>**中文版**：这是一个跨[区域/产品/客户]的绩效数据集。识别哪些相对于平均水平表现优异和不佳。显示驱动此绩效的指标并根据发现推荐2项行动。 |
| **分析季度业务指标** | I'm reviewing performance data for Q[insert quarter]. Analyze this dataset [upload CSV] for key trends in revenue, churn, and customer acquisition. Highlight 3 insights I should share with the board and suggest follow-up questions I should ask.<br><br>**中文版**：我正在审查Q[插入季度]的绩效数据。分析此数据集[上传 CSV]的收入、流失和客户获取的关键趋势。突出3个我应该与董事会分享的洞察，并建议我应该问的后续问题。 |
| **分析客户旅程流失** | I uploaded a funnel dataset showing customer journey stages. Analyze conversion rates between each stage and identify the largest drop-offs. Suggest 2–3 hypotheses and next steps to test or investigate.<br><br>**中文版**：我上传了显示客户旅程阶段的漏斗数据集。分析每个阶段之间的转化率并识别最大流失点。建议2-3个假设以及要测试或调查的后续步骤。 |
| **基于历史趋势预测下季度** | Based on this historical data [upload], build a simple forecast for [KPI, e.g. revenue] over the next quarter. Use a basic time-series model and explain any assumptions made. Present as a short briefing I can share with my leadership team.<br><br>**中文版**：基于此历史数据[上传]，为下一个季度的[KPI，例如：收入]建立简单预测。使用基本时间序列模型并解释所做的任何假设。作为简短简报呈现，我可以与领导团队分享。 |
| **优先排序战略投资** | I uploaded a dataset of ongoing or proposed initiatives with cost, impact score, and estimated time to ROI. Help me prioritize these initiatives by building a simple scoring model and plotting effort vs. impact. Summarize the top 3 recommendations.<br><br>**中文版**：我上传了一个正在进行的或提议的计划数据集，包含成本、影响力评分和预计 ROI 时间。通过构建简单评分模型并绘制工作量与影响力来帮助我优先排序这些计划。总结前3个推荐。 |

---

## 五、高管可视化与框架设计 (Executive Visualization & Framework Design)

ChatGPT 创建清晰的战略图表、矩阵和概念视觉，用于高管演示和讲故事。

| 使用场景 | 提示词 |
|---------|--------|
| **构建竞争格局网格** | Based on the following list of competitors and their differentiators [paste], create a 2x2 matrix plotting them by [x axis] and [y axis]. Label each quadrant and include our position.<br><br>**中文版**：基于以下竞争对手列表及其差异化因素[粘贴]，创建2x2矩阵，按[x 轴]和[y 轴]绘制它们。标记每个象限并包括我们的位置。 |
| **设计2x2市场定位矩阵** | Create a 2x2 matrix plotting companies in [industry] by [X-axis: e.g. pricing] and [Y-axis: e.g. innovation]. Label each quadrant, add 6–8 companies, and highlight where we fit. Keep it suitable for a board presentation.<br><br>**中文版**：创建2x2矩阵，按[X轴：例如：定价]和[Y轴：例如：创新]绘制[行业]中的公司。标记每个象限，添加6-8个公司，并突出我们适合的位置。使其适合董事会演示。 |
| **展示转型时间线** | Create a visual timeline showing a company transformation journey from [year 1] to [year 3]. Include key milestones: strategy shifts, team growth, market expansion. Style: simple, bold, professional.<br><br>**中文版**：创建可视化时间线，展示从[第1年]到[第3年]的公司转型旅程。包括关键里程碑：战略转变、团队增长、市场扩张。风格：简洁、大胆、专业。 |
| **可视化战略愿景或飞轮** | Create a high-level strategic flywheel or vision diagram for a company focused on [industry or goal]. Show how inputs (e.g. customers, data, feedback) loop into outputs (e.g. growth, innovation). Keep it clean, modern, and executive-ready.<br><br>**中文版**：为专注于[行业或目标]的公司创建高层战略飞轮或愿景图。展示输入（例如：客户、数据、反馈）如何循环到输出（例如：增长、创新）。保持整洁、现代和高管就绪。 |
| **说明未来产品愿景** | Create a conceptual image of a future product vision for [industry/product]. Highlight features that reflect innovation and customer benefit. Style should be forward-looking, abstract but clear.<br><br>**中文版**：为[行业/产品]创建未来产品愿景的概念图像。突出反映创新和客户利益的功能。风格应该是前瞻性的、抽象但清晰的。 |

---

## 使用建议

### 推荐工具
- **深度研究**：用于投资者和市场情报
- **Canvas**：用于实时编辑沟通文档
- **推理模型**：用于更多战略洞察

### 最佳实践
1. 将方括号 `[...]` 中的内容替换为具体信息
2. 定期更新市场趋势和投资者情绪研究
3. 保留成功的沟通模板
4. 使用数据驱动决策
5. 平衡战略愿景与执行细节

---

*文档生成时间：2025年8月*
*原文链接：https://academy.openai.com/public/clubs/work-users-ynjqu/resources/use-cases-executives*
