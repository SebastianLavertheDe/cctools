# ChatGPT for Engineers - 工程团队提示词集合

> 来源：OpenAI Academy
> 标题：ChatGPT for engineers
> 描述：为工程团队提供精选提示词库，涵盖系统架构可视化、技术研究、文档编写、调试和数据分析
> 最后更新：2025年8月12日

## 概述

工程师专注于构建、修复和优化系统。他们关心编写干净的代码、高效解决技术问题，以及减少错误或停机时间。ChatGPT 可以通过生成代码片段、解释复杂概念、审查逻辑、编写文档和加速重复性任务来提供帮助，使工程师能够专注于更快地交付高质量工作。

---

## 一、研究与基准 (Research & Benchmarking)

使用 ChatGPT 提供技术、工具和行业实践的比较分析。

| 使用场景 | 提示词 |
|---------|--------|
| **评估云提供商迁移** | I'm an infrastructure engineer evaluating cloud migration options. Context: We're moving from on-prem to the cloud for a fintech backend. Output: Compare AWS, GCP, and Azure for scalability, pricing, compliance, and developer tooling. Include citations.<br><br>**中文版**：我是一名正在评估云迁移选项的基础设施工程师。背景：我们正在将金融科技后端从本地迁移到云端。输出：比较 AWS、GCP 和 Azure 在可扩展性、定价、合规性和开发者工具方面的差异。包括引用。 |
| **研究实时应用框架** | I'm building a real-time collaboration tool. Context: We need low-latency and scalability. Output: Compare top frameworks (e.g., SignalR, Socket.io, WebRTC) with use cases, pros/cons, and current usage by other SaaS companies. Include sources.<br><br>**中文版**：我正在构建实时协作工具。背景：我们需要低延迟和可扩展性。输出：比较顶级框架（例如：SignalR、Socket.io、WebRTC）的使用场景、利弊以及当前其他 SaaS 公司的使用情况。包括来源。 |
| **可观测性工具基准** | Benchmark the top observability tools. Context: We want to move from basic logging to full-stack monitoring. Output: Create a comparison table of features, pricing, integrations for Datadog, New Relic, Prometheus, and OpenTelemetry. Include sources.<br><br>**中文版**：基准测试顶级可观测性工具。背景：我们希望从基本日志记录转向全栈监控。输出：创建 Datadog、New Relic、Prometheus 和 OpenTelemetry 的功能、定价、集成比较表。包括来源。 |
| **分析物流领域的AI/ML趋势** | I'm researching AI/ML adoption in logistics systems. Context: Our company is considering integrating predictive routing. Output: A 5-paragraph summary on current trends, vendors, and implementation patterns. Include citations and links.<br><br>**中文版**：我正在研究 AI/ML 在物流系统中的采用。背景：我们公司正在考虑集成预测路由。输出：关于当前趋势、供应商和实施模式的5段摘要。包括引用和链接。 |
| **调查合规最佳实践** | Research best practices for GDPR/CCPA compliance so we can help kick off discussions with our legal team. Context: Our app stores sensitive user data in the EU and US. Output: A compliance checklist with citations, sorted by regulation. Include links to documentation and regulations.<br><br>**中文版**：研究 GDPR/CCPA 合规的最佳实践，以便我们帮助启动与法务团队的讨论。背景：我们的应用在欧盟和美国存储敏感用户数据。输出：按法规排序的合规检查清单，包含引用。包括文档和法规链接。 |

---

## 二、技术审查与文档 (Technical Reviews & Documentation)

使用 ChatGPT 进行工程文档、设计审查和规划材料。**使用 Canvas 进行实时编辑。**

| 使用场景 | 提示词 |
|---------|--------|
| **审查系统设计文档** | I've drafted a technical design document for [insert project or feature]. Review it for clarity, architectural soundness, and completeness. Highlight any missing considerations or questions reviewers may raise.<br><br>**中文版**：我已经为[插入项目或功能]起草了技术设计文档。审查其清晰度、架构合理性和完整性。突出任何遗漏的考虑事项或审查者可能提出的问题。 |
| **记录内部API行为** | I need to document how this internal API works for other developers. Here's the relevant code, schema, and usage examples: [insert materials]. Create clear documentation including endpoints, input/output formats, and expected behavior.<br><br>**中文版**：我需要为其他开发人员记录此内部 API 的工作方式。这是相关代码、架构和使用示例：[插入材料]。创建清晰的文档，包括端点、输入/输出格式和预期行为。 |
| **起草值班工程师运行手册** | I need to create a runbook for on-call engineers supporting [insert system]. Draft one that includes sections for system overview, common alerts, diagnostic steps, and escalation procedures.<br><br>**中文版**：我需要为支持[插入系统]的值班工程师创建运行手册。起草一份包含系统概述、常见警报、诊断步骤和升级程序部分的运行手册。 |
| **起草新员工入职指南** | I need to write an onboarding guide for new engineers joining [insert team]. Create a draft with sections for required tools, access setup, codebase overview, and first tasks. Make it suitable for self-service onboarding.<br><br>**中文版**：我需要为加入[插入团队]的新工程师编写入职指南。创建包含所需工具、访问设置、代码库概述和首批任务部分的草稿。使其适合自助式入职。 |
| **从规范编写JIRA工单** | Based on this engineering spec for [insert task or feature], write a JIRA ticket that includes the problem statement, context, goals, acceptance criteria, and technical notes for implementation.<br><br>**中文版**：基于[插入任务或功能]的工程规范，编写 JIRA 工单，包括问题陈述、背景、目标、验收标准和实施技术说明。 |

---

## 三、调试与优化 (Debugging & Optimization)

ChatGPT 可以帮助诊断、故障排除和改进系统性能和可靠性。

| 使用场景 | 提示词 |
|---------|--------|
| **调试生产环境故障系统** | A system in production is intermittently failing, and we're struggling to isolate the root cause. Based on the following logs, metrics, and recent changes: [insert context], help identify the most likely causes and suggest next steps for mitigation.<br><br>**中文版**：生产环境中的系统间歇性故障，我们正在努力找出根本原因。基于以下日志、指标和最近变更：[插入背景]，帮助识别最可能的原因并建议缓解的后续步骤。 |
| **分析性能瓶颈** | Our service is experiencing latency and degraded performance during peak usage. Here are metrics, logs, and relevant traces: [insert context]. Help identify the bottlenecks and recommend specific optimizations.<br><br>**中文版**：我们的服务在高峰使用期间遇到延迟和性能下降。这是指标、日志和相关跟踪：[插入背景]。帮助识别瓶颈并推荐具体的优化措施。 |
| **分析数据管道故障** | A critical data pipeline failed in yesterday's run. Here are the logs, data volume trends, and error outputs: [insert context]. Analyze what likely went wrong and provide recommendations to prevent recurrence.<br><br>**中文版**：关键数据管道在昨天的运行中失败。这是日志、数据量趋势和错误输出：[插入背景]。分析可能出了什么问题并提供防止复发的建议。 |
| **建议可观测性改进** | We currently use [insert tools] for monitoring [insert service]. Review our observability setup and suggest improvements across metrics, logging, alerting, and dashboards to improve issue detection and debugging.<br><br>**中文版**：我们目前使用[插入工具]来监控[插入服务]。审查我们的可观测性设置，并建议在指标、日志、警报和仪表板方面的改进，以提高问题检测和调试能力。 |
| **头脑风暴测试边缘案例** | We're preparing test cases for [insert feature/system]. Brainstorm potential edge cases and failure scenarios that may not be covered by standard testing, including unusual user inputs, system state changes, and concurrency issues.<br><br>**中文版**：我们正在为[插入功能/系统]准备测试用例。头脑风暴可能的边缘情况和故障场景，这些可能未被标准测试覆盖，包括异常用户输入、系统状态更改和并发问题。 |

---

## 四、数据分析与报告 (Data Analysis & Reporting)

ChatGPT 协助分析数据集、识别趋势和创建可视化报告。

| 使用场景 | 提示词 |
|---------|--------|
| **识别产品使用日志趋势** | Analyze this CSV of product usage logs. Context: We want to identify usage trends over time and across user segments. Output: Summary stats + line or bar charts highlighting key trends.<br><br>**中文版**：分析此产品使用日志 CSV。背景：我们希望识别随时间和跨用户群体的使用趋势。输出：摘要统计+突出关键趋势的折线或柱状图。 |
| **可视化系统错误率趋势** | Plot error rates over time from this dataset. Context: It contains application logs from the last month. Output: A time-series chart with callouts for error spikes and a short interpretation.<br><br>**中文版**：从此数据集绘制错误率随时间的变化。背景：它包含上个月的应用日志。输出：带有错误峰值标注的时间序列图表和简短解释。 |
| **分析性能测试结果** | Analyze this set of performance test results. Context: It compares two versions of our backend service. Output: Side-by-side comparison charts + text summary of improvements or regressions.<br><br>**中文版**：分析这组性能测试结果。背景：它比较了我们后端服务的两个版本。输出：并排比较图表+改进或回归的文本摘要。 |
| **基于影响优先排序错误** | Analyze this bug report dataset. Context: Each row includes severity, frequency, and affected users. Output: A prioritized list of top bugs with charts showing frequency vs. severity.<br><br>**中文版**：分析此错误报告数据集。背景：每行包括严重性、频率和受影响的用户。输出：顶级错误的优先列表，并显示频率与严重性的图表。 |
| **总结用户调查反馈** | Summarize this user feedback CSV. Context: It includes ratings and open text responses from a recent survey. Output: Key themes, sentiment scores, and charts showing distribution of ratings.<br><br>**中文版**：总结此用户反馈 CSV。背景：它包括最近调查的评分和开放式文本回复。输出：关键主题、情感评分和显示评分分布的图表。 |

---

## 五、系统架构与可视化 (System Architecture & Visualization)

ChatGPT 可以支持生成图表、流程图以及复杂系统和流程的可视化表示。

| 使用场景 | 提示词 |
|---------|--------|
| **创建组件图** | I need to visualize the architecture of [insert system or service]. Generate a component diagram showing key services, data flows, and third-party integrations. Use clear labels and group components logically.<br><br>**中文版**：我需要可视化[插入系统或服务]的架构。生成显示关键服务、数据流和第三方集成的组件图。使用清晰的标签并逻辑分组组件。 |
| **可视化系统架构** | Create an image of the system architecture. Context: It's a microservices-based e-commerce platform with services for payments, catalog, and user profiles. Output: Diagram with labeled services and data flow arrows.<br><br>**中文版**：创建系统架构图像。背景：它是基于微服务的电子商务平台，具有支付、目录和用户资料服务。输出：带标签服务和数据流箭头的图表。 |
| **向利益相关者解释CI/CD流程** | Create an image that explains our CI/CD process. Context: This is for a presentation to business stakeholders. Output: Diagram showing dev → build → test → deploy steps with basic icons and short descriptions.<br><br>**中文版**：创建解释我们 CI/CD 流程的图像。背景：这是面向业务利益相关者的演示。输出：显示开发→构建→测试→部署步骤的图表，带有基本图标和简短描述。 |
| **建模ML管道数据流** | Create an image showing data flow in a machine learning pipeline. Context: We collect raw user data, clean it, train models, and serve predictions. Output: A labeled flowchart from raw data to inference.<br><br>**中文版**：创建显示机器学习管道中数据流的图像。背景：我们收集原始用户数据，清理数据，训练模型并提供预测。输出：从原始数据到推理的带标签流程图。 |
| **绘制应用内客户旅程图** | Create a customer journey map through our mobile banking app. Context: Steps include onboarding, account linking, transactions, and support. Output: A visual flowchart with steps, screens, and decision points.<br><br>**中文版**：创建通过我们移动银行应用的客户旅程地图。背景：步骤包括入职、账户链接、交易和支持。输出：带有步骤、屏幕和决策点的可视化流程图。 |

---

## 使用建议

### 推荐工具
- **Canvas**：用于实时编辑文档
- **深度研究**：用于技术趋势和合规研究

### 最佳实践
1. 将方括号 `[...]` 中的内容替换为具体信息
2. 提供足够的上下文以获得准确的技术分析
3. 使用真实日志和数据进行分析
4. 保留常用代码模板和文档模板
5. 定期更新工具和技术的基准研究

---

*文档生成时间：2025年8月*
*原文链接：https://academy.openai.com/public/clubs/work-users-ynjqu/resources/use-cases-engineers*
