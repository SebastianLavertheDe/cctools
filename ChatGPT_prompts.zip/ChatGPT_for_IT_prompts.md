# ChatGPT for IT - IT团队提示词集合

> 来源：OpenAI Academy
> 标题：ChatGPT for IT
> 描述：为 IT 团队提供提示词，涵盖生成脚本、调试代码、起草文档和响应支持工单等用例
> 最后更新：2025年8月12日

## 概述

IT 团队负责保持系统安全、高效和可访问。ChatGPT 可以帮助他们更快地移动并减少手动工作。它可以总结日志、编写自动化步骤、解释复杂配置，并帮助向非技术团队传达技术变更。

---

## 一、云与供应商评估 (Cloud & Vendor Evaluations)

ChatGPT 可以帮助比较云服务、IT供应商和新兴技术解决方案以指导战略决策。**使用深度研究和网络搜索获取更深入的实时洞察。**

| 使用场景 | 提示词 |
|---------|--------|
| **比较云提供商** | Compare AWS, Azure, and GCP for our use case: [insert workload or environment]. Consider cost, uptime, global availability, and ease of integration. Research using 2025 data, and present a table comparing each provider with a recommendation at the end.<br><br>**中文版**：针对我们的使用案例比较 AWS、Azure 和 GCP：[插入工作负载或环境]。考虑成本、正常运行时间、全球可用性和集成便利性。使用2025年数据研究，并在表格中比较每个提供商并在最后给出建议。 |
| **生成供应商比较图表** | Research and compare remote access vendors for enterprise use. Focus on features, pricing, integrations, and support quality. Use 2025 data, and summarize the findings in a comparison table with notes.<br><br>**中文版**：研究和比较企业用的远程访问供应商。重点关注功能、定价、集成和支持质量。使用2025年数据，并在比较表中总结发现。 |
| **比较AI可观测性工具** | I'm an IT Manager at [insert company]. I'm evaluating observability platforms. Research current offerings, pricing, supported environments, and key differentiators in 2025. Include citations and summarize insights in a comparison table with a recommendation for a mid-size engineering org.<br><br>**中文版**：我是[插入公司]的 IT 经理。我正在评估可观测性平台。研究2025年的当前产品、定价、支持环境和关键差异化因素。包括引用，并在比较表中总结洞察，为中型工程组织提供建议。 |
| **调查零信任框架** | I'm a Security Architect working on adopting a zero trust model. Research leading frameworks (e.g., NIST 800-207) and recent updates to best practices in 2024–2025. Include real-world implementation case studies where possible. Provide a summarized comparison and an executive-ready briefing.<br><br>**中文版**：我是一名正在采用零信任模型的安全架构师。研究领先的框架（例如：NIST 800-207）和2024-2025年最佳实践的最新更新。尽可能包括真实世界的实施案例研究。提供总结比较和高管就绪的简报。 |

---

## 二、IT合规与安全 (IT Compliance & Security)

ChatGPT 指导合规要求、访问审查和安全态势评估的研究和文档。

| 使用场景 | 提示词 |
|---------|--------|
| **评估全球数据驻留法律** | I'm an IT Compliance Lead planning a global data storage architecture. Research 2025 data residency requirements across the EU, US, APAC, and LATAM. Include regulatory restrictions and preferred cloud regions. Cite official documentation and summarize findings in a table grouped by region.<br><br>**中文版**：我是一名正在规划全球数据存储架构的 IT 合规负责人。研究2025年欧盟、美国、亚太和拉美的数据驻留要求。包括监管限制和首选云区域。引用官方文档并在按区域分组的表格中总结发现。 |
| **分析远程访问工具** | As an IT Service Delivery Lead, I need a secure, scalable remote access tool for our hybrid team. Compare current vendors (e.g., BeyondTrust, TeamViewer Tensor, Chrome Remote Desktop) for enterprise use in 2025. Focus on SSO support, encryption, session logging, and pricing. Provide a security-focused executive summary with links to primary sources.<br><br>**中文版**：作为 IT 服务交付负责人，我需要为混合团队提供安全、可扩展的远程访问工具。比较2025年企业使用的当前供应商（例如：BeyondTrust、TeamViewer Tensor、Chrome Remote Desktop）。重点关注 SSO 支持、加密、会话记录和定价。提供专注于安全的高管摘要并附主要来源链接。 |
| **生成合规检查清单** | Based on SOC 2 guidelines, create a checklist of IT-specific controls to review for an upcoming internal audit. Use this existing audit prep document as background. Organize the checklist by domain (e.g., access, change management, incident response).<br><br>**中文版**：基于 SOC 2 指南，创建 IT 特定控制检查清单以审查即将进行的内部审计。使用此现有审计准备文档作为背景。按领域（例如：访问、变更管理、事件响应）组织检查清单。 |
| **验证访问控制** | Review this access matrix of users, roles, and systems. Check whether each user's access level follows our least-privilege policy. Identify any potential overprovisioning, and provide a table listing users with permissions that may need to be scaled back.<br><br>**中文版**：审查此用户、角色和系统的访问矩阵。检查每个用户的访问级别是否遵循我们的最小权限策略。识别任何潜在的过度配置，并提供列出权限可能需要缩减的用户的表格。 |
| **审查API安全态势** | Review this API schema and a sample set of traffic logs. Identify common API security issues such as poor input validation or lack of authentication. Provide a bullet-point list of findings with suggested fixes.<br><br>**中文版**：审查此 API 架构和流量日志样本。识别常见的 API 安全问题，如输入验证不足或缺乏身份验证。提供带建议修复的要点发现列表。 |

---

## 三、IT运营与资产管理 (IT Operations & Asset Management)

ChatGPT 支持运营规划、资产生命周期政策、入职流程和 IT 工单优先级排序。

| 使用场景 | 提示词 |
|---------|--------|
| **起草IT入职检查清单** | Create a checklist for onboarding new hires from an IT perspective. Include key steps for account provisioning, security training, and hardware setup. Use this outline of our current process, and present the checklist organized by day or week.<br><br>**中文版**：创建从 IT 角度入职新员工的检查清单。包括账户配置、安全培训和硬件设置的关键步骤。使用我们当前流程的大纲，并按天或周组织检查清单。 |
| **生成硬件生命周期政策** | Create a draft policy for managing the lifecycle of company laptops and desktops. Reference this spreadsheet of device ages and current replacement costs. Write a formal document with guidance on replacement timelines, support windows, and environmental considerations.<br><br>**中文版**：创建管理公司笔记本电脑和台式机生命周期的草稿政策。参考此设备年龄和当前更换成本的电子表格。编写正式文档，提供关于更换时间表、支持窗口和环境考虑的指导。 |
| **起草资产库存政策** | Write a formal policy for maintaining and auditing IT asset inventory. Use this list of tools, departments, and stakeholders as a starting point. Include purpose, responsibilities, and process for inventory reconciliation.<br><br>**中文版**：编写维护和审计 IT 资产库存的正式政策。使用此工具、部门和利益相关者列表作为起点。包括目的、责任和库存对账流程。 |
| **帮助优先排序IT工单** | Review this queue of open IT support tickets. Use this prioritization rubric based on impact, urgency, and SLA. Reorder the tickets accordingly and present the list as a prioritized backlog with a short reason for each ranking.<br><br>**中文版**：审查此开放的 IT 支持工单队列。使用基于影响、紧急程度和 SLA 的优先级排序标准。相应地重新排序工单，并将列表呈现为带每个排名简短理由的优先积压工作。 |
| **跟踪硬件生命周期风险** | Use this device inventory file containing purchase dates, models, and OS versions. Highlight which assets are past end-of-life or nearing refresh thresholds. Create a table of at-risk devices and include a narrative summary for IT leadership.<br><br>**中文版**：使用包含购买日期、型号和操作系统版本的此设备库存文件。突出哪些资产已过生命周期或接近刷新阈值。创建有风险设备的表格，并为 IT 领导层包括叙述性摘要。 |

---

## 四、IT沟通与事件管理 (IT Communication & Incident Management)

ChatGPT 协助起草沟通、事后分析和 IT 服务的灾难恢复计划。

| 使用场景 | 提示词 |
|---------|--------|
| **起草事后分析** | Summarize the recent [insert system or service] outage. Include the root cause, timeline of events, user impact, and actions taken. Use information from the incident ticket or war room notes, and format the summary as a shareable internal postmortem report.<br><br>**中文版**：总结最近的[插入系统或服务]中断。包括根本原因、事件时间线、用户影响和采取的行动。使用事件工单或作战室笔记的信息，并将摘要格式化为可共享的内部事后报告。 |
| **创建DR运行手册草稿** | Create a draft disaster recovery playbook for a critical production service. Use this system diagram and our recovery objectives (RTO, RPO). Organize the playbook into steps to take before, during, and after a service outage.<br><br>**中文版**：为关键生产服务创建灾难恢复运行手册草稿。使用此系统图和我们的恢复目标（RTO、RPO）。将运行手册组织为服务中断之前、期间和之后要采取的步骤。 |
| **编写停机内部沟通** | Write a professional internal communication announcing planned downtime for [insert system or tool]. Include timing, affected users, impact on work, and who to contact for questions. Write the message in the tone of an IT team update.<br><br>**中文版**：编写专业内部沟通，宣布[插入系统或工具]的计划停机时间。包括时间、受影响用户、工作影响以及有问题时联系谁。以 IT 团队更新的语气编写消息。 |
| **将错误日志翻译成通俗语言** | Help translate these system error logs into language that can be understood by a non-technical executive. Use definitions where needed, and summarize what each log entry means in a few clear sentences. Present the explanation as an email draft.<br><br>**中文版**：帮助将这些系统错误日志翻译成非技术主管可以理解的语言。在需要处使用定义，并用几句清晰的句子总结每个日志条目的含义。将解释作为电子邮件草稿呈现。 |
| **评估SaaS工具冗余** | Review our current list of SaaS tools used by IT, engineering, and ops. Use the attached spreadsheet with cost, team usage, and tool functions. Identify overlapping tools and recommend 3–5 candidates for consolidation, explaining why each was chosen in a short summary report.<br><br>**中文版**：审查 IT、工程和运营当前使用的 SaaS 工具列表。使用附带电子表格中的成本、团队使用和工具功能。识别重叠工具并推荐3-5个整合候选，在简短摘要报告中解释选择每个的原因。 |

---

## 五、IT监控与优化 (IT Monitoring & Optimization)

ChatGPT 分析日志、正常运行时间和系统性能以提出改进建议和预测趋势。

| 使用场景 | 提示词 |
|---------|--------|
| **总结系统健康趋势** | Analyze the system health logs from the last 30 days. Focus on spikes in CPU/memory, service outages, and recurring error codes. Provide a concise summary of the key issues and add brief commentary on possible causes or needed follow-ups.<br><br>**中文版**：分析过去30天的系统健康日志。关注 CPU/内存峰值、服务中断和重复错误代码。提供关键问题的简明摘要并添加关于可能原因或所需后续行动的简短评论。 |
| **建议系统监控改进** | Review our monitoring setup for [insert system] based on the current configuration and recent alert history. Identify 2–3 areas for improvement, such as gaps in alert coverage, noise reduction, or metrics tuning. Present the suggestions in a short internal memo.<br><br>**中文版**：基于当前配置和最近警报历史审查[插入系统]的监控设置。识别2-3个改进领域，如警报覆盖空白、噪音减少或指标调整。在简短内部备忘录中呈现建议。 |
| **分析服务正常运行时间和事件频率** | Review this CSV with daily uptime % and incident logs for [insert service] over the past quarter. Identify patterns in outages, frequency of issues by severity, and calculate overall uptime. Summarize findings and suggest actions for improvement in a brief report.<br><br>**中文版**：审查此 CSV，其中包含上个季度[插入服务]的每日正常运行时间百分比和事件日志。识别中断模式、按严重程度的问题频率并计算总体正常运行时间。在简短报告中总结发现并建议改进行动。 |
| **审计用户访问日志异常** | Analyze this user access log export. Identify users or IP addresses with unusual access frequency, after-hours logins, or failed attempts. Flag suspicious patterns and summarize results in a security review format.<br><br>**中文版**：分析此用户访问日志导出。识别访问频率异常、非工作时间登录或失败尝试的用户或 IP 地址。标记可疑模式并以安全审查格式总结结果。 |
| **预测IT支持工单量** | Analyze this export of support ticket volume by week for the past 12 months. Identify seasonality trends and forecast volume for the next quarter. Visualize the trend and provide commentary for capacity planning.<br><br>**中文版**：分析过去12个月按周计算的支持工单量导出。识别季节性趋势并预测下季度工单量。可视化趋势并为容量规划提供评论。 |

---

## 使用建议

### 推荐工具
- **深度研究**：用于供应商评估和合规研究
- **网络搜索**：获取实时IT洞察

### 最佳实践
1. 将方括号 `[...]` 中的内容替换为具体信息
2. 定期更新供应商比较和基准研究
3. 保留常用脚本和文档模板
4. 使用真实日志数据进行分析
5. 优先处理安全相关工单

---

*文档生成时间：2025年8月*
*原文链接：https://academy.openai.com/public/clubs/work-users-ynjqu/resources/use-cases-it*
