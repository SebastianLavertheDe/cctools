# ChatGPT for Finance - 财务团队提示词集合

> 来源：OpenAI Academy
> 标题：ChatGPT for finance
> 描述：为财务领导者提供专注于财务的提示词，简化分析、报告和可视化任务，涵盖基准、预测、高管沟通、流程优化和视觉故事叙述
> 最后更新：2025年8月12日

## 概述

财务团队专注于推动财务清晰度、管理风险并确保其组织做出由数据支持的明智战略决策。ChatGPT 可以通过加速财务分析、生成高管就绪的摘要、自动化例行文档编制以及头脑风暴战略财务计划来支持他们——同时考虑合规性和准确性标准。

---

## 一、财务基准与市场分析 (Financial Benchmarking & Market Analysis)

ChatGPT 支持通过基准、竞争对手研究和行业分析来评估财务表现和市场定位。**使用网络搜索或深度研究获取更深入的实时洞察。**

| 使用场景 | 提示词 |
|---------|--------|
| **基准财务表现** | Benchmark our financial performance against companies in the [insert industry] sector. Use public data to compare gross margin, net profit, and CAC. Present results in a table with source links.<br><br>**中文版**：将我们的财务表现与[插入行业]领域的公司进行基准比较。使用公开数据比较毛利率、净利润和 CAC。在带源链接的表格中呈现结果。 |
| **基准费用比率与同行** | I'm a finance lead at [insert company or industry]. Research current SG&A and R&D expense ratios for 5 comparable companies in the [insert sector, e.g., SaaS, manufacturing, healthcare]. Provide a table with metrics, source links, and a short analysis of how we compare.<br><br>**中文版**：我是[插入公司或行业]的财务负责人。研究[插入领域，例如：SaaS、制造、医疗保健]中5家可比公司的当前 SG&A 和 R&D 费用比率。提供包含指标、源链接的表格以及我们比较的简短分析。 |
| **竞争性融资分析** | I'm a CFO preparing for our next fundraising round. Research recent funding rounds (past 12 months) in [insert industry]. Summarize deal sizes, valuations, lead investors, and positioning. Format as a briefing memo with source citations and clear bullet-point insights.<br><br>**中文版**：我是一名正在为下一轮融资做准备的 CFO。研究[插入行业]最近的融资轮（过去12个月）。总结交易规模、估值、领投投资者和定位。格式化为简报备忘录，包含来源引用和清晰的要点洞察。 |
| **比较全球税收法规** | I manage global finance compliance. Research and compare corporate tax rates and reporting requirements in [insert countries]. Focus on tax incentives, reporting thresholds, and penalties. Deliver a comparison chart with links to official sources.<br><br>**中文版**：我管理全球财务合规。研究和比较[插入国家]的企业税率和报告要求。关注税收激励、报告门槛和惩罚。提供带官方来源链接的比较图表。 |
| **ESG财务策略基准** | I'm updating our ESG financial strategy. Research how leading companies in [insert industry] integrate ESG into financial planning and disclosures. Summarize 3–5 examples with their KPIs, reporting cadence, and financial impact. Include references.<br><br>**中文版**：我正在更新我们的 ESG 财务策略。研究[插入行业]的领先公司如何将 ESG 整合到财务规划和披露中。总结3-5个示例及其 KPI、报告节奏和财务影响。包括参考。 |

---

## 二、财务规划与预测 (Financial Planning & Forecasting)

ChatGPT 指导收入预测、预算规划和场景建模以指导战略决策。**上传数据以进行更深入分析并使用推理模型获取更多战略洞察。**

| 使用场景 | 提示词 |
|---------|--------|
| **预测收入趋势** | Forecast next quarter's revenue based on the past 6 quarters of data. Use the trends from our [insert dataset or industry] to explain your reasoning. Present the forecast in a table and write a short executive summary.<br><br>**中文版**：基于过去6个季度的数据预测下一季度的收入。利用我们[插入数据集或行业]的趋势来解释你的推理。在表格中呈现预测并编写简短的高管摘要。 |
| **起草预算假设用于规划** | Help me draft budget assumptions for our next annual plan. Context: [insert department/region/product info]. Output should include key assumptions, rationale, and any dependencies.<br><br>**中文版**：帮助我们下一个年度计划起草预算假设。背景：[插入部门/区域/产品信息]。输出应包括关键假设、理由和任何依赖关系。 |
| **建模现金流场景** | Model 3 cash flow scenarios based on these variables: [insert inputs such as revenue range, delays, or costs]. Output as a table with assumptions, key drivers, and estimated cash impact.<br><br>**中文版**：基于这些变量建模3个现金流场景：[插入输入，如收入范围、延迟或成本]。作为带假设、关键驱动因素和估计现金影响的表格输出。 |
| **进行工具ROI分析** | Conduct an ROI analysis for a new [insert software or tool] we're considering. Context: [insert usage or pricing data]. Output should include payback period, assumptions, and a short risk assessment.<br><br>**中文版**：对我们正在考虑的新[插入软件或工具]进行 ROI 分析。背景：[插入使用或定价数据]。输出应包括回收期、假设和简短风险评估。 |
| **比较定价策略** | Compare 3 potential pricing strategies for our [insert product or service]. Use prior pricing data from [insert past year] for context. Output should be a side-by-side comparison table with pros, cons, and estimated impact.<br><br>**中文版**：比较我们的[插入产品或服务]的3种潜在定价策略。使用[插入过去年份]的先前定价数据作为背景。输出应该是并排比较表格，包含利弊和估计影响。 |

---

## 三、财务沟通与报告 (Financial Communication & Reporting)

ChatGPT 支持高管沟通、董事会更新和为不同受众简化财务信息。**使用 Canvas 进行实时编辑。**

| 使用场景 | 提示词 |
|---------|--------|
| **准备董事会会议谈话要点** | Draft financial talking points for an upcoming board meeting. Use our [insert Q2 results or P&L summary] as input. Write the talking points in bullet format, focusing on topline metrics and risk/upsides.<br><br>**中文版**：为即将召开的董事会会议起草财务谈话要点。使用我们的[插入 Q2 结果或 P&L 摘要]作为输入。以要点格式撰写谈话要点，关注顶层指标和风险/上行因素。 |
| **编写投资者更新摘要** | Write a summary for our next investor update. Use highlights from [insert performance report or fundraising update]. Format the output as a concise executive email suitable for external stakeholders.<br><br>**中文版**：为我们的下一个投资者更新编写摘要。使用[插入绩效报告或融资更新]的亮点。将输出格式化为适合外部利益相关者的简明高管电子邮件。 |
| **起草QBR财务幻灯片内容** | Draft the financial performance section for our next QBR deck. Use these inputs: [insert Q2 revenue, margin trends, notable cost changes]. Output as slide bullets with 1–2 takeaway lines.<br><br>**中文版**：为我们下一个 QBR 演示文稿起草财务绩效部分。使用这些输入：[插入 Q2 收入、利润率趋势、显著成本变化]。作为带1-2个要点的幻灯片要点输出。 |
| **翻译差异分析** | Translate this variance analysis into a manager-friendly summary. Source: [insert analysis]. Write in plain language with a brief explanation of why each variance occurred.<br><br>**中文版**：将此差异分析翻译为管理者友好的摘要。来源：[插入分析]。用通俗语言编写，并简要解释每个差异发生的原因。 |
| **总结审计发现** | Summarize key findings from our internal audit. Use this document: [insert findings]. Output should be a summary for executives, with 3 themes and recommended next steps.<br><br>**中文版**：总结我们内部审计的关键发现。使用此文档：[插入发现]。输出应该是给高管的摘要，包含3个主题和推荐的后续步骤。 |

---

## 四、运营财务与流程改进 (Operational Finance & Process Improvement)

ChatGPT 分析成本结构、识别效率机会并加强财务运营。**使用推理模型获取更多战略洞察。**

| 使用场景 | 提示词 |
|---------|--------|
| **分析成本降低机会** | Identify cost reduction opportunities from our recent budget report. Use the breakdown from [insert cost center or department] to evaluate. Provide a table with opportunities, projected savings, and any potential risks.<br><br>**中文版**：从我们最近的预算报告中识别成本降低机会。使用[插入成本中心或部门]的细分进行评估。提供包含机会、预计节省和任何潜在风险的表格。 |
| **评估M&A目标匹配度** | Evaluate the financial and strategic fit of an M&A target. Use this context: [insert company profile or key metrics]. Output should be a table of pros/cons and a 3-paragraph summary of risk/reward.<br><br>**中文版**：评估 M&A 目标的财务和战略匹配度。使用此背景：[插入公司简介或关键指标]。输出应该是利弊表格和风险/回报的3段摘要。 |
| **识别会计流程差距** | Review our current accounting close checklist and suggest improvements. Use this documentation: [insert SOP or task list]. Output should highlight bottlenecks and recommend process updates.<br><br>**中文版**：审查我们当前的会计结账检查清单并建议改进。使用此文档：[插入 SOP 或任务清单]。输出应突出瓶颈并推荐流程更新。 |
| **审查供应商付款以进行整合** | Analyze vendor payments in this data [upload file]. Identify top 10 vendors by spend, spot any duplication (e.g., similar vendor names), and recommend vendors to consolidate. Output a table and short cost-reduction summary.<br><br>**中文版**：分析此数据中的供应商付款[上传文件]。识别支出前10的供应商，发现任何重复（例如，相似的供应商名称），并推荐要整合的供应商。输出表格和简短的成本降低摘要。 |
| **采购策略成本杠杆** | I'm leading a finance initiative to cut procurement costs. Research strategies used by Fortune 500 companies to reduce procurement spend without harming supplier relationships. Present 3–5 tactics with cost impact examples and cited sources.<br><br>**中文版**：我正在领导一项削减采购成本的财务计划。研究财富500强公司用于在不损害供应商关系的情况下减少采购支出的策略。用成本影响示例和引用来源展示3-5种策略。 |

---

## 五、财务仪表板与视觉故事叙述 (Financial Dashboards & Visual Storytelling)

ChatGPT 创建财务数据、流程和战略洞察的可视化表示，以增强清晰度和影响力。**在 ChatGPT 中创建图像以获得自定义视觉。**

| 使用场景 | 提示词 |
|---------|--------|
| **可视化收入增长漏斗** | Create an image of a revenue growth funnel with labeled stages: Acquisition → Activation → Revenue → Retention → Expansion. Use a clean, modern style suitable for an executive finance presentation. Include icons for each stage.<br><br>**中文版**：创建带标记阶段的收入增长漏斗图像：获取→激活→收入→留存→扩张。使用适合高管财务演示的简洁现代风格。为每个阶段包括图标。 |
| **说明预算规划工作流程** | Create a horizontal process flow diagram showing a budget planning cycle: Forecasting → Review → Stakeholder Input → Approval → Tracking → Adjustment. Use corporate-style visuals with subtle color and labels.<br><br>**中文版**：创建显示预算规划周期的水平流程图：预测→审查→利益相关者输入→批准→跟踪→调整。使用企业风格视觉效果，带有微妙的颜色和标签。 |
| **ESG财务影响视觉** | Create a visual showing how ESG initiatives can impact finance metrics. Show links between sustainability investments and cost savings, risk mitigation, and investor interest. Use a modern, green-themed design with arrows.<br><br>**中文版**：创建一个视觉，展示 ESG 计划如何影响财务指标。显示可持续性投资与成本节约、风险缓解和投资者兴趣之间的联系。使用现代绿色主题设计和箭头。 |
| **高管仪表板概念** | Generate a conceptual image of a finance executive dashboard showing high-level KPIs: Revenue, Gross Margin, Burn Rate, Runway, and Budget vs. Actual. Use a clean layout with panels and placeholder numbers.<br><br>**中文版**：生成财务高管仪表板的概念图像，显示高层 KPI：收入、毛利率、烧钱率、跑道和预算与实际。使用带有面板和占位数字的整洁布局。 |

---

## 使用建议

### 推荐工具
- **网络搜索**：用于基准和市场研究
- **深度研究**：用于深入的财务洞察
- **Canvas**：用于实时编辑财务报告
- **推理模型**：用于更多战略洞察

### 最佳实践
1. 将方括号 `[...]` 中的内容替换为具体信息
2. 定期更新行业基准和财务比率
3. 使用真实数据进行分析以获得准确洞察
4. 保留成功的报告模板
5. 平衡准确性和可读性

---

*文档生成时间：2025年8月*
*原文链接：https://academy.openai.com/public/clubs/work-users-ynjqu/resources/use-cases-finance*
