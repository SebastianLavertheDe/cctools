# ChatGPT for Sales - 销售团队提示词集合

> 来源：OpenAI Academy
> 标题：ChatGPT for sales
> 描述：专注于销售的提示词，旨在简化外展、策略、竞争情报、数据分析和可视化赋能任务
> 最后更新：2025年8月12日

## 概述

销售团队专注于了解客户需求，并找到正确的方式展示他们的产品或服务如何提供帮助。他们花费大量时间撰写邮件、准备会议、处理异议和更新 CRM 笔记。ChatGPT 可以加速重复性任务——如起草外展消息、总结通话或定制后续跟进——从而保持组织有序、更快响应，并专注于建立关系。

---

## 一、外展与沟通 (Outreach & Communication)

专注于为潜在客户和客户制作个性化、有说服力的沟通内容。使用 **Canvas** 进行实时编辑，或使用 **Custom GPT** 创建可重复的流程并与工作空间中的其他人共享。

| 使用场景 | 提示词 |
|---------|--------|
| **起草个性化冷启动外展邮件** | Write a short, compelling cold email to a [job title] at [company name] introducing our product. Use the background below to customize it. Background: [insert value props or ICP info]. Format it in email-ready text.<br><br>**中文版**：给[公司名称]的[职位头衔]写一封简短、引人注目的冷启动邮件，介绍我们的产品。使用以下背景信息进行定制。背景：[插入价值主张或 ICP 信息]。以邮件就绪文本格式输出。 |
| **优化演示后跟进邮件** | Rewrite this follow-up email after a demo to sound more consultative. Original email: [paste here]. Include recap, next steps, and call scheduling CTA. Output as email text.<br><br>**中文版**：重写这封演示后的跟进邮件，使其更具咨询性。原始邮件：[在此粘贴]。包括回顾、后续步骤和电话预约 CTA。以邮件文本格式输出。 |
| **为重点客户起草续约提案** | Draft a renewal pitch for [customer name] based on this renewal history and value data: [paste data]. Include key ROI proof points and renewal recommendation. Output as a short pitch and optional follow-up email.<br><br>**中文版**：根据以下续约历史和价值数据为[客户名称]起草续约提案：[粘贴数据]。包括关键 ROI 证明点和续约建议。输出为简短提案和可选的后续邮件。 |
| **创建销售代表活动摘要** | Write a daily update summarizing key rep activities. Inputs: [paste call summaries or CRM exports]. Make it upbeat and concise. Output as 3–5 bullet message.<br><br>**中文版**：写一份每日更新，总结关键代表活动。输入：[粘贴通话摘要或 CRM 导出数据]。使其积极向上且简洁。以 3-5 条要点消息格式输出。 |
| **起草高管管道状态更新** | Summarize our pipeline health this month for execs. Inputs: [paste data]. Include total pipeline, top risks, biggest wins, and forecast confidence. Write it like a short exec update.<br><br>**中文版**：为本月高管总结我们的管道健康状况。输入：[粘贴数据]。包括总管道、顶级风险、最大胜利和预测信心。像简短的高管更新那样撰写。 |

---

## 二、销售策略与规划 (Sales Strategy & Planning)

指导账户、区域和管道规划以实现战略增长。使用 **推理模型** 获得更深入的战略洞察。

| 使用场景 | 提示词 |
|---------|--------|
| **生成战略客户计划** | Create an account plan for [customer name]. Use these inputs: company profile, known priorities, current product usage, stakeholders, and renewal date. Output a structured plan with goals, risks, opportunities, and next steps.<br><br>**中文版**：为[客户名称]创建客户计划。使用这些输入：公司简介、已知优先事项、当前产品使用情况、利益相关者和续约日期。输出包含目标、风险、机会和后续步骤的结构化计划。 |
| **设计区域规划框架** | Create a territory planning guide for our next fiscal year. Inputs: team headcount, target industries, regions, and historical revenue. Recommend allocation method and sample coverage plan.<br><br>**中文版**：为我们的下一个财年创建区域规划指南。输入：团队人数、目标行业、区域和历史收入。推荐分配方法和样本覆盖计划。 |
| **使用公司人口数据对客户优先排序** | I have this list of accounts: [paste sample]. Prioritize them based on [criteria: industry, size, funding, tech stack]. Output a ranked list with reasons why.<br><br>**中文版**：我有这个客户列表：[粘贴样本]。基于[标准：行业、规模、资金、技术栈]对它们进行优先排序。输出带原因的排序列表。 |
| **使用加权评分识别高潜力客户** | Score accounts based on [insert rules—e.g., company size, engagement score, intent signals]. Data: [Upload account list]. Output top 10 ranked accounts with their score and a note explaining why.<br><br>**中文版**：基于[插入规则——例如：公司规模、参与度评分、意向信号]对客户进行评分。数据：[上传客户列表]。输出前 10 个排名客户及其评分和解释原因的说明。 |
| **区域市场进入规划** | I'm evaluating market entry into [region/country] for our [SaaS solution]. Research local buying behaviors, competitive landscape, economic conditions, and regulatory concerns. Format as a go/no-go market readiness summary with citations and action steps.<br><br>**中文版**：我正在评估我们的[SaaS 解决方案]进入[区域/国家]的市场。研究当地购买行为、竞争格局、经济条件和监管问题。格式化为进入/不进入的市场准备度摘要，并附带引用和行动步骤。 |

---

## 三、竞争情报与赋能 (Competitive Intelligence & Enablement)

为销售团队配备洞察、定位和工具，以在竞争中获胜。使用 **深度研究** 或 **网络搜索** 获得更深入的实时洞察。

| 使用场景 | 提示词 |
|---------|--------|
| **创建竞争对手对战卡** | Create a battlecard for [competitor name]. Use these notes: [insert positioning data]. Include strengths, weaknesses, how we win, and quick talk track. Output as table format.<br><br>**中文版**：为[竞争对手名称]创建对战卡。使用这些笔记：[插入定位数据]。包括优势、劣势、我们如何获胜以及快速话术。以表格格式输出。 |
| **竞争定位分析** | I'm preparing a competitive battlecard for [competitor name]. Research their pricing model, product positioning, recent customer wins/losses, and sales motion. Compare it to ours based on these strengths: [insert]. Output a 1-page summary with citations.<br><br>**中文版**：我正在为[竞争对手名称]准备竞争对战卡。研究他们的定价模型、产品定位、最近的客户得失和销售运作。基于这些优势将其与我们的进行比较：[插入]。输出带引用的 1 页摘要。 |
| **创建销售赋能单页文档** | Create a one-pager to help reps pitch [product name] to [persona]. Include key benefits, features, common use cases, and competitor differentiators. Format as copy-ready enablement doc.<br><br>**中文版**：创建单页文档，帮助代表向[角色画像]推销[产品名称]。包括关键优势、功能、常见用例和竞争对手差异化。格式化为可复制的赋能文档。 |
| **准备销售异议反驳** | Create rebuttals to these common objections: [insert 2–3 objections]. Make them sound natural and confident, and include a backup stat or story where useful. Output as list.<br><br>**中文版**：为这些常见异议创建反驳：[插入 2-3 个异议]。使它们听起来自然自信，并在有用处包含备用统计数据或故事。以列表格式输出。 |
| **在公共领域查找客户证明点** | Research recent online reviews, social mentions, and testimonials about [our product OR competitor product]. Focus on what customers are praising or criticizing. Summarize top 5 quotes, what persona each came from, and where it was posted. Include links.<br><br>**中文版**：研究关于[我们的产品或竞争对手产品]的最近在线评论、社交媒体提及和推荐。重点关注客户在赞扬或批评什么。总结前 5 条引用，每条来自什么角色，以及发布位置。包括链接。 |

---

## 四、数据分析与绩效洞察 (Data Analysis & Performance Insights)

ChatGPT 分析销售数据以发现绩效趋势和可操作的洞察。

| 使用场景 | 提示词 |
|---------|--------|
| **按阶段分析管道转化率** | Analyze this sales pipeline export. Calculate conversion rates between each stage and identify the biggest drop-off point. Data: [Upload pipeline CSV]. Output a short summary and a table of conversion % by stage.<br><br>**中文版**：分析此销售管道导出。计算每个阶段之间的转化率并识别最大流失点。数据：[上传管道 CSV]。输出简短摘要和按阶段列出的转化率表。 |
| **按成交率识别顶尖代表** | From this dataset of rep activities and closed deals, calculate the close rate for each rep and rank them. Data: [Upload rep performance CSV]. Output a ranked list and a sentence for each rep's strength.<br><br>**中文版**：从此代表活动和已成交数据集中，计算每个代表的成交率并对其进行排名。数据：[上传代表绩效 CSV]。输出排序列表和每个代表优势的一句话。 |
| **可视化跨季度成交速度** | Use this CRM export to calculate average deal velocity per quarter (days from lead to close). Data: [Upload with open/close dates]. Show velocity trend in a simple chart and summarize the trendline.<br><br>**中文版**：使用此 CRM 导出计算每季度平均成交速度（从线索到成交的天数）。数据：[上传包含开放/关闭日期的数据]。在简单图表中显示速度趋势并总结趋势线。 |
| **总结活动对已成交的归因** | Match campaign sources to closed-won deals from this data. Identify which campaign drove the most closed revenue. Data: [Upload campaign + deal export]. Output a ranked list and a short campaign summary.<br><br>**中文版**：将活动来源与这些数据中的已成交交易进行匹配。确定哪个活动产生了最多的已成交收入。数据：[上传活动 + 交易导出]。输出排序列表和简短的活动摘要。 |
| **生成绩效对比图表** | Here's a table of rep performance by quarter: [paste data]. Compare top vs bottom performers. Show chart with trends and call out key differences. Output as table + insights.<br><br>**中文版**：这是按季度列出的代表绩效表：[粘贴数据]。比较顶级与底层表现者。显示带趋势的图表并指出关键差异。输出为表格 + 洞察。 |

---

## 五、视觉与销售资料 (Visuals & Sales Collateral)

ChatGPT 为销售赋能创建视觉资产和结构化资料。

| 使用场景 | 提示词 |
|---------|--------|
| **以漏斗视图可视化销售流程** | Create a funnel graphic showing our sales stages: [insert stages]. Make it clean and easy to read for onboarding docs. Output as simple image.<br><br>**中文版**：创建一个显示我们销售阶段的漏斗图形：[插入阶段]。使其简洁易读，适合入职文档。输出为简单图像。 |
| **可视化 B2B 销售漏斗** | Create an image of a standard B2B SaaS sales funnel with these stages: Prospecting, Discovery, Demo, Proposal, Closed Won/Lost. Use clean, modern icons and text labels. Output should be clear enough for use in a slide or enablement doc.<br><br>**中文版**：创建具有这些阶段的标准 B2B SaaS 销售漏斗图像：潜在客户开发、发现、演示、提案、已成交/已流失。使用简洁的现代图标和文本标签。输出应足够清晰，以便在幻灯片或赋能文档中使用。 |
| **说明关键销售角色画像** | Create professional illustrations for 3 personas: (1) CFO of a mid-market company, (2) VP of IT at a global enterprise, and (3) Operations Manager at a logistics firm. Style should be flat and modern, ideal for use in a one-pager or training slide.<br><br>**中文版**：为 3 个角色创建专业插图：(1) 中型市场公司的 CFO、(2) 全球企业的 IT 副总裁、(3) 物流公司的运营经理。风格应为扁平化和现代，适合在单页文档或培训幻灯片中使用。 |
| **创建区域覆盖地图** | Create a simplified U.S. map showing sales territories split by region: West, Central, East. Use distinctive color zones and label key states. Output should look clean and suitable for a sales kickoff deck.<br><br>**中文版**：创建简化的美国地图，显示按区域划分的销售区域：西部、中部、东部。使用独特的颜色区域并标记关键州。输出应看起来整洁，适合销售启动演示文稿。 |
| **起草团队庆祝图形** | Design a fun, modern graphic to celebrate "Top Rep of the Month." Include a placeholder for name/photo and stylized trophy or badge. Style should match internal brand or newsletter vibe.<br><br>**中文版**：设计一个有趣、现代的图形来庆祝"本月最佳代表"。包括姓名/照片的占位符以及风格化的奖杯或徽章。风格应与内部品牌或新闻通讯氛围相匹配。 |

---

## 使用建议

### 工具推荐
- **Canvas**：用于实时编辑和优化外展邮件、文档
- **Custom GPT**：创建可重复的提示词流程并与团队共享
- **Reasoning Model**：用于更深入的战略规划和分析
- **Deep Research / Web Search**：获取实时的竞争情报和市场洞察

### 最佳实践
1. 将方括号 `[...]` 中的内容替换为具体信息
2. 根据产品/服务的特性调整价值主张
3. 定期更新竞争对战卡和销售资料
4. 使用数据导出（CSV）进行更准确的分析
5. 保持品牌一致性，定制视觉资产

---

*文档生成时间：2025年8月*
*原文链接：https://academy.openai.com/public/clubs/work-users-ynjqu/resources/use-cases-sales*
