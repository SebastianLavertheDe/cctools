# ChatGPT for Marketing - 营销团队提示词集合

> 来源：OpenAI Academy
> 标题：ChatGPT for marketing
> 描述：为营销和品牌团队提供提示词，简化策略、内容创作和绩效分析，涵盖活动规划、竞争研究、创意开发、数据驱动洞察和视觉品牌沟通
> 最后更新：2025年8月12日

## 概述

今天的营销人员既是战略家，又是讲故事的人和分析师。他们关注共鸣品牌叙事、可衡量的管道影响，并在不牺牲真实性或包容性的情况下保持领先于不断发展的渠道。ChatGPT 帮助他们头脑风暴活动角度、更快迭代文案、发现受众洞察、压力测试信息，以便他们能够以市场速度交付高质量资产。

---

## 一、活动规划与策略 (Campaign Planning & Strategy)

ChatGPT 支持构建、组织和头脑风暴营销活动。**使用推理模型进行战略头脑风暴。**

| 使用场景 | 提示词 |
|---------|--------|
| **可视化活动时间线** | Build a timeline for our upcoming multi-channel campaign. Key dates and milestones are: [insert info]. Output as a horizontal timeline with phases, owners, and deadlines.<br><br>**中文版**：为我们即将到来的多渠道活动构建时间线。关键日期和里程碑是：[插入信息]。作为带阶段、负责人和截止日期的水平时间线输出。 |
| **头脑风暴活动创意** | Brainstorm 5 creative campaign ideas for our upcoming [event/launch]. The audience is [insert target], and our goal is [insert goal]. Include a theme, tagline, and 1-2 core tactics per idea.<br><br>**中文版**：为我们即将到来的[活动/发布]头脑风暴5个创意活动想法。受众是[插入目标]，我们的目标是[插入目标]。每个想法包括主题、标语和1-2个核心策略。 |
| **起草创意简报** | Create a creative brief for our next paid media campaign. Here's the goal, audience, and offer: [insert info]. Include sections for objective, audience insights, tone, assets needed, and KPIs.<br><br>**中文版**：为我们的下一个付费媒体活动创建创意简报。这是目标、受众和优惠：[插入信息]。包括目标、受众洞察、语气、所需资产和 KPI 部分。 |
| **构建信息传递框架** | Build a messaging framework for a new product. The product details are: [insert info]. Output a table with 3 pillars: key benefits, proof points, and emotional triggers.<br><br>**中文版**：为新产品构建信息传递框架。产品详情是：[插入信息]。输出包含3个支柱的表格：关键利益、证明点和情感触发因素。 |
| **构建客户旅程地图** | Create a customer journey map for our [product/service]. Our typical customer is [insert profile]. Break it into stages, goals, touchpoints, and potential pain points per stage. Output as a table.<br><br>**中文版**：为我们的[产品/服务]创建客户旅程地图。我们的典型客户是[插入简介]。将其分解为阶段、目标、接触点和每个阶段的潜在痛点。作为表格输出。 |

---

## 二、竞争与市场研究 (Competitive & Market Research)

ChatGPT 可以支持竞争对手分析、基准和新兴趋势的研究。**使用网络搜索或深度研究获取更深入的实时洞察。**

| 使用场景 | 提示词 |
|---------|--------|
| **竞争内容分析** | Research how top 5 competitors structure their blog content strategy. Include tone, topics, frequency, SEO focus, and CTAs. Provide URLs, takeaways, and a table summarizing common and standout tactics.<br><br>**中文版**：研究前5名竞争对手如何构建其博客内容策略。包括语气、主题、频率、SEO 重点和 CTA。提供 URL、要点和总结常见和突出策略的表格。 |
| **研究买家行为中的新兴趋势** | Research 2024 trends in how [type] buyers research and evaluate [industry] products. Include behavior shifts, content preferences, and channel usage. Cite sources and format as a short briefing with bullet-point insights.<br><br>**中文版**：研究[类型]买家在2024年如何研究和评估[行业]产品的趋势。包括行为转变、内容偏好和渠道使用。引用来源并格式化为带要点洞察的简短简报。 |
| **研究区域活动基准** | Research typical CTRs, CPCs, and conversion rates for digital campaigns targeting [location] in 2024. Focus on [ad channels]. Include source links and a table comparing each metric by country.<br><br>**中文版**：研究2024年针对[地点]的数字活动的典型 CTR、CPC 和转化率。关注[广告渠道]。包括源链接和按国家比较每个指标的表格。 |
| **研究行业活动竞争对手存在** | Compile a summary of how our competitors are participating in [insert upcoming event]. Include booth activations, speaking sessions, sponsorships, and media coverage. Output as a table with links and analysis.<br><br>**中文版**：总结我们的竞争对手如何参与[插入即将到来的活动]。包括展台激活、演讲环节、赞助和媒体报道。作为带链接和分析的表格输出。 |
| **研究面向营销人员的AI工具** | Research the most recommended [tools] for marketers by function (e.g. copywriting, planning, analytics, design). Create a table with features, pricing, pros/cons, and primary use case. Include sources.<br><br>**中文版**：研究按功能（例如：文案、规划、分析、设计）为营销人员最推荐的[工具]。创建包含功能、定价、利弊和主要用例的表格。包括来源。 |

---

## 三、内容与创意开发 (Content & Creative Development)

ChatGPT 可以支持生成营销文案、视觉和资产。**使用 Canvas 进行实时编辑。**

| 使用场景 | 提示词 |
|---------|--------|
| **起草产品发布电子邮件** | Write a launch email for our new product. Use the following info about the product and target audience: [insert details]. Make it engaging and persuasive, formatted as a marketing email ready for review.<br><br>**中文版**：为我们的新产品编写发布电子邮件。使用关于产品和目标受众的以下信息：[插入详情]。使其引人入胜和有说服力，格式化为准备审查的营销电子邮件。 |
| **生成广告文案变体** | Create 5 ad copy variations for a [channel] campaign. Here's the campaign theme and audience info: [insert context]. Each version should test a different hook or tone.<br><br>**中文版**：为[渠道]活动创建5个广告文案变体。这是活动主题和受众信息：[插入背景]。每个版本应该测试不同的钩子或语气。 |
| **创建社交媒体系列** | Draft a 3-post social media series promoting [event, product, or milestone]. Use this background for context: [paste details]. Each post should include copy and a suggested visual description.<br><br>**中文版**：起草3条社交媒体帖子系列，推广[活动、产品或里程碑]。使用此背景作为背景：[粘贴详情]。每个帖子应包括文案和建议的视觉描述。 |
| **创建客户聚光灯帖子** | Write a customer spotlight post based on this success story: [paste key details]. Make it conversational, authentic, and aligned to our brand voice. Output as a LinkedIn post draft.<br><br>**中文版**：基于此成功故事编写客户聚光灯帖子：[粘贴关键详情]。使其对话式、真实并与我们的品牌声音一致。作为 LinkedIn 帖子草稿输出。 |
| **创建解释视频脚本** | Draft a script for a 60-second explainer video about [product/topic]. Here's what it should cover: [insert info]. Make it punchy and clear, with suggested visuals or animations.<br><br>**中文版**：为关于[产品/主题]的60秒解释视频起草脚本。它应该涵盖：[插入信息]。使其有力清晰，并带有建议的视觉或动画。 |

---

## 四、数据分析与优化 (Data Analysis & Optimization)

ChatGPT 可以分析数据、预测趋势并改善决策。**上传数据以进行更深入分析。**

| 使用场景 | 提示词 |
|---------|--------|
| **识别表现最佳的营销渠道** | Analyze this marketing performance spreadsheet and identify which channels had the highest ROI. The file includes data from Q1–Q2 campaigns across email, social, paid search, and events. Summarize top 3 channels and create a chart showing ROI by channel.<br><br>**中文版**：分析此营销绩效电子表格并识别哪些渠道具有最高 ROI。文件包括 Q1-Q2 跨电子邮件、社交、付费搜索和活动的活动数据。总结前3个渠道并创建按渠道显示 ROI 的图表。 |
| **发现客户流失模式** | Review this customer churn dataset and identify common characteristics of churned customers. Use columns like tenure, product usage, and support tickets to group insights. Output a short summary with a chart or table showing top risk factors.<br><br>**中文版**：审查此客户流失数据集并识别流失客户的共同特征。使用任期、产品使用和支持工单等列来分组洞察。输出简短摘要和显示顶级风险因素的图表或表格。 |
| **总结调查结果** | Summarize insights from this post-campaign customer feedback survey. The file includes satisfaction ratings and open-ended responses. Provide a 3-bullet executive summary and a chart of top satisfaction drivers.<br><br>**中文版**：总结此后活动客户反馈调查的洞察。文件包括满意度评级和开放式回复。提供3要点高管摘要和顶级满意度驱动因素的图表。 |
| **预测下季度线索量** | Use this historical lead volume data from the past 6 quarters to project expected lead volume for the next quarter. Highlight any trends, seasonal patterns, and output a simple forecast chart.<br><br>**中文版**：使用过去6个季度的此历史线索量数据预测下一季度的预期线索量。突出任何趋势、季节性模式并输出简单的预测图表。 |
| **优化活动预算分配** | Based on this spreadsheet of previous campaign spend and returns, recommend a revised budget allocation for next quarter. Focus on maximizing ROI while reducing spend on underperforming channels. Output as a table with new % allocations.<br><br>**中文版**：基于先前活动支出和回报的此电子表格，建议下季度的修订预算分配。专注于最大化 ROI，同时减少表现不佳渠道的支出。作为带新分配百分比的表格输出。 |

---

## 五、视觉与品牌沟通 (Visual & Brand Communication)

专注于制作连贯的视觉策略、品牌叙事和创意概念。**使用 ChatGPT 创建图像。**

| 使用场景 | 提示词 |
|---------|--------|
| **制定品牌风格指南大纲** | Create an outline for a brand style guide for [company/product]. Include sections for typography, color palette, logo usage, tone of voice, imagery style, and do's/don'ts.<br><br>**中文版**：为[公司/产品]创建品牌风格指南大纲。包括排版、调色板、标志使用、语气、图像风格和做/不做部分。 |
| **概念化视觉叙事** | Brainstorm 3 visual storytelling concepts for a brand campaign on [theme]. Include a concept name, visual style, and key narrative elements (e.g., story arc, mood, colors).<br><br>**中文版**：为[主题]的品牌活动头脑风暴3个视觉叙事概念。包括概念名称、视觉风格和关键叙事元素（例如：故事弧、情绪、颜色）。 |
| **创建视觉活动情绪板** | Create a moodboard with 4 visuals for our [campaign or brand update]. Theme is [describe theme], and the tone should be [describe tone]. Use photoreal or illustrated style.<br><br>**中文版**：为我们的[活动或品牌更新]创建带有4个视觉的情绪板。主题是[描述主题]，语气应该是[描述语气]。使用照片写实或插图风格。 |
| **评估品牌一致性** | Review the following marketing assets [insert links/files] and evaluate brand consistency in terms of tone, visuals, and messaging. Provide 3 strengths and 3 gaps with recommendations.<br><br>**中文版**：审查以下营销资产[插入链接/文件]并评估语气、视觉和信息传递的品牌一致性。提供3个优势和3个差距及建议。 |
| **更新品牌标识概念** | Suggest 3 creative directions to refresh our brand identity. Include possible color palettes, typography styles, visual motifs, and tone updates that align with [audience/market shift].<br><br>**中文版**：建议3个创意方向以更新我们的品牌标识。包括与[受众/市场转变]一致的可能调色板、排版风格、视觉母题和语气更新。 |

---

## 使用建议

### 推荐工具
- **Canvas**：用于实时编辑内容
- **推理模型**：用于战略规划
- **网络搜索**：用于竞争和市场研究
- **深度研究**：用于深入洞察

### 最佳实践
1. 将方括号 `[...]` 中的内容替换为具体信息
2. 定期更新竞争研究基准
3. 使用数据驱动决策优化营销策略
4. 保留成功的文案模板
5. 保持品牌一致性

---

*文档生成时间：2025年8月*
*原文链接：https://academy.openai.com/public/clubs/work-users-ynjqu/resources/use-cases-marketing*
