# ChatGPT for Product - 产品团队提示词集合

> 来源：OpenAI Academy
> 标题：ChatGPT for product
> 描述：为产品团队提供高影响力提示词，涵盖竞争研究、策略、UX设计、内容创作和数据分析
> 最后更新：2025年8月12日

## 概述

产品团队是客户需求、业务目标和技术执行之间的桥梁。他们致力于发现洞察、验证想法，并制定平衡用户价值和战略影响力的路线图。ChatGPT 可以加速他们的工作流程，生成 PRD、总结客户反馈、探索竞争对手产品、头脑风暴功能，让他们有更多时间用于决策和策略制定。

---

## 一、竞争与市场研究 (Competitive & Market Research)

ChatGPT 通过分析竞争对手、市场趋势和监管因素来指导产品策略。**使用深度研究和网络搜索获取更多实时洞察。**

| 使用场景 | 提示词 |
|---------|--------|
| **比较竞争对手的入职UX** | Research how 3 key competitors structure their onboarding flow for new users. Include screenshots, key steps, and points of friction or delight. Synthesize a comparison table and recommendations for improvement. Target product: [Insert product]<br><br>**中文版**：研究3个关键竞争对手如何为新用户构建入职流程。包括截图、关键步骤以及摩擦或愉悦点。综合比较表格和改进建议。目标产品：[插入产品] |
| **竞争对手定价策略基准** | I'm a product manager launching a new SaaS product. Research how top 5 competitors in this space structure their pricing tiers, freemium vs. paid, feature gating, and upsell triggers. Use public sources and include URLs. Output: A comparison table with insights and risks.<br><br>**中文版**：我是一名正在推出新 SaaS 产品的产品经理。研究该领域前5名竞争对手如何构建其定价层级、免费与付费、功能门控和增购触发器。使用公开来源并包含 URL。输出：包含洞察和风险的比较表格。 |
| **比较技术栈选项** | Compare the pros and cons of integrating [technology/tool A] vs. [technology/tool B] into our product. Focus on scalability, cost, support, and developer experience. Include citations.<br><br>**中文版**：比较将[技术/工具 A]与[技术/工具 B]集成到我们产品中的利弊。重点关注可扩展性、成本、支持和开发体验。包括引用。 |
| **识别新功能的监管风险** | I'm a PM scoping a [feature] for financial services. Research recent regulatory guidance in the US, UK, and EU around the use of [feature] in customer-facing products. Summarize by region with citations. Output: A table of legal considerations to flag for our legal team and product design implications.<br><br>**中文版**：我正在为金融服务规划一个[功能]。研究美国、英国和欧盟围绕在面向客户的产品中使用[功能]的最新监管指导。按地区总结并包含引用。输出：需要向法律团队标记的法律考虑事项表格和产品设计影响。 |
| **研究产品驱动增长的顶级策略** | Research the top 7 product-led growth strategies used by fast-scaling SaaS companies in the last 2 years. Prioritize those with measurable impact. Include 1–2 examples per tactic and source links. Output: Ranked list with strategy, example, and success metric.<br><br>**中文版**：研究过去2年中快速扩张的 SaaS 公司使用的前7大产品驱动增长策略。优先考虑具有可衡量影响的策略。每个策略包含1-2个示例和源链接。输出：包含策略、示例和成功指标的排序列表。 |

---

## 二、产品策略与路线图 (Product Strategy & Roadmapping)

ChatGPT 指导产品举措的优先级排序、货币化和愿景设定。**使用推理模型获取更多战略洞察。**

| 使用场景 | 提示词 |
|---------|--------|
| **基于影响力优先排序路线图** | Review this list of upcoming product initiatives. Use the data provided (impact scores, effort estimates, and strategic alignment notes) to suggest priority order. Present the reordered list with justification for each recommendation. [Insert initiative list]<br><br>**中文版**：审查此即将推出的产品举措列表。使用提供的数据（影响力评分、工作量估算和战略一致性说明）建议优先顺序。展示重新排序的列表并为每个建议提供理由。 |
| **探索货币化模型** | We're considering pricing changes. Based on this product value and audience, suggest 3 monetization strategies. Include pros, cons, and examples of companies using each. [Insert product and audience details]<br><br>**中文版**：我们正在考虑定价变更。基于此产品价值和受众，建议3种货币化策略。包括利弊以及使用每种策略的公司示例。 |
| **起草产品愿景声明** | Based on this long-term goal and user need, write a concise product vision statement. Keep it inspiring and grounded in real outcomes. [Insert product goal]<br><br>**中文版**：基于此长期目标和用户需求，编写简洁的产品愿景声明。使其具有启发性并基于真实结果。 |
| **从客户反馈中头脑风暴功能想法** | Review this batch of customer feedback from the past quarter. Identify pain points and generate a list of 5 feature ideas to address recurring themes. [Insert feedback or summary]<br><br>**中文版**：审查上个季度的这批客户反馈。识别痛点并生成5个功能创意列表以解决重复出现的主题。 |
| **规划A/B测试实验** | Review this list of product UI changes and propose 2 A/B test setups. Include hypothesis, success metrics, and potential outcomes. [Insert UI changes or user goals]<br><br>**中文版**：审查此产品 UI 变更列表并提出2个 A/B 测试设置。包括假设、成功指标和潜在结果。 |

---

## 三、产品内容与沟通 (Product Content & Communication)

ChatGPT 创建清晰且引人入胜的产品文档、发布材料和内部内容。**使用 Canvas 进行实时编辑。**

| 使用场景 | 提示词 |
|---------|--------|
| **为新功能起草PRD** | Based on this feature idea and customer need, write a first-draft PRD. Include user story, problem statement, solution overview, acceptance criteria, and success metrics. [Insert context or problem]<br><br>**中文版**：基于此功能创意和客户需求，编写 PRD 初稿。包括用户故事、问题陈述、解决方案概述、验收标准和成功指标。 |
| **起草更新日志和发布说明** | Using this release summary, draft user-facing changelog notes for our next version release. Use a friendly, clear tone and group by category (e.g., new, improved, fixed). [Insert release notes or ticket list]<br><br>**中文版**：使用此发布摘要，为我们下一个版本发布起草面向用户的更新日志说明。使用友好、清晰的语气并按类别分组（例如：新增、改进、修复）。 |
| **创建上市FAQ** | Draft an internal FAQ for our sales and support teams about our upcoming feature launch. Use this background and anticipated questions. Write in a confident, informative tone. [Insert feature and launch details]<br><br>**中文版**：为我们的销售和支持团队起草关于即将推出的功能发布的内部 FAQ。使用此背景和预期问题。以自信、信息丰富的语气撰写。 |
| **生成一句话价值主张** | Based on this feature description, write 3 versions of a clear, compelling one-sentence value proposition. Tailor each one to a different target audience. [Insert feature description]<br><br>**中文版**：基于此功能描述，编写3个版本的清晰、引人注目的一句话价值主张。为每个版本定制不同的目标受众。 |
| **起草新产品推销演示文稿** | Create a 5-slide outline for a pitch deck introducing our new product to internal stakeholders. Include problem, solution, market, product overview, and timeline. [Insert product idea]<br><br>**中文版**：创建5幻灯片大纲，用于向内部利益相关者介绍我们的新产品。包括问题、解决方案、市场、产品概述和时间线。 |

---

## 四、UX与视觉设计 (UX & Visual Design)

ChatGPT 生成用户旅程、概念视觉效果和产品设计素材。

| 使用场景 | 提示词 |
|---------|--------|
| **可视化用户旅程地图** | Create a user journey map for our [insert user persona] going through [insert experience]. Include emotional highs/lows, touchpoints, and moments of friction. Output as a visual flow.<br><br>**中文版**：为我们的[插入用户画像]创建用户旅程地图，展示其经历[插入体验]的过程。包括情感高低点、接触点和摩擦时刻。输出为可视化流程。 |
| **设计入职流程线框** | Generate a wireframe-style image of a 3-step onboarding flow for a finance app. Steps include: linking an account, setting financial goals, and reviewing suggestions. Style: greyscale wireframe with labels.<br><br>**中文版**：为金融应用的3步入职流程生成线框风格图像。步骤包括：链接账户、设定财务目标和审查建议。风格：带标签的灰度线框。 |
| **说明产品比较视觉效果** | Create a side-by-side visual comparison of two app dashboards: one cluttered with too many metrics, and one simplified with actionable insights. Style: dashboard UI, minimalistic, neutral branding.<br><br>**中文版**：创建两个应用仪表板的并排视觉比较：一个因过多指标而杂乱，一个通过可操作洞察简化。风格：仪表板 UI、极简主义、中性品牌。 |
| **设计用户旅程信息图** | Generate a user journey infographic showing the onboarding experience for a mobile health-tracking app. Include key milestones, emotions, and friction points. Style: infographic, vertical layout, soft colors.<br><br>**中文版**：生成用户旅程信息图，展示移动健康追踪应用的入职体验。包括关键里程碑、情感和摩擦点。风格：信息图、垂直布局、柔和色彩。 |

---

## 五、数据分析与洞察 (Data Analysis & Insights)

ChatGPT 分析反馈、日志和实验以发现趋势并指导决策。

| 使用场景 | 提示词 |
|---------|--------|
| **分析产品反馈主题** | Analyze this set of user feedback and identify the 4 most frequent themes. Summarize each with example quotes and suggested product implications. [Insert feedback or data dump]<br><br>**中文版**：分析此用户反馈集并识别4个最频繁的主题。用示例引用和建议的产品影响总结每个主题。 |
| **综合使用数据洞察** | Based on the following product usage data, summarize 3 key behavioral trends and what they suggest about user needs. Recommend 2 follow-up investigations. [Insert data or summary]<br><br>**中文版**：基于以下产品使用数据，总结3个关键行为趋势及其对用户需求的暗示。建议2项后续调查。 |
| **识别产品采用风险** | Review our product rollout plan and highlight 5 risks to successful adoption. Include likelihood, impact, and mitigation recommendations. [Insert rollout plan or summary]<br><br>**中文版**：审查我们的产品推出计划并突出5个成功采用的风险。包括可能性、影响和缓解建议。 |
| **分析A/B测试结果** | Review the results of our recent A/B test (test vs. control). Identify statistical significance, key metrics that changed, and recommend next steps. Present insights clearly with graphs if needed. [Upload test data]<br><br>**中文版**：审查我们最近 A/B 测试（测试组 vs 对照组）的结果。识别统计显著性、变化的关键指标，并建议后续步骤。清晰展示洞察，必要时提供图表。 |
| **比较跨客户群体的功能采用** | Use this data to compare how small business vs. enterprise customers adopt our key features. Highlight major differences, usage frequencies, and retention impact. Format output as a table with insights. [Upload CSV or describe dataset]<br><br>**中文版**：使用此数据比较小企业与企企业客户如何采用我们的关键功能。突出主要差异、使用频率和留存影响。将输出格式化为带洞察的表格。 |

---

## 使用建议

### 推荐工具
- **Deep Research**：用于深入的竞争和市场研究
- **Web Search**：获取实时市场洞察
- **Canvas**：用于实时编辑产品文档
- **Reasoning Model**：用于更多战略洞察

### 最佳实践
1. 将方括号 `[...]` 中的内容替换为具体信息
2. 使用真实数据进行分析以获得更准确的洞察
3. 定期更新竞争对手研究和基准
4. 保留成功的 PRD 模板以供团队复用
5. 结合用户定性和定量数据进行决策

---

*文档生成时间：2025年8月*
*原文链接：https://academy.openai.com/public/clubs/work-users-ynjqu/resources/use-cases-product*
