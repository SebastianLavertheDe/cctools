# ChatGPT for Managers - 管理者提示词集合

> 来源：OpenAI Academy
> 标题：ChatGPT for managers
> 描述：为管理者提供精选提示词，简化团队领导任务，从设定战略目标、分析团队健康状况到培养文化和有效沟通
> 最后更新：2025年8月12日

## 概述

团队管理者负责保持项目正轨、指导下属并将团队产出与业务目标对齐。他们需要处理日常检查、状态更新、绩效评估和跨职能协调，往往没有足够时间进行深度工作。ChatGPT 帮助管理者简化重复性任务，如起草反馈、总结会议和准备更新。

---

## 一、战略规划与对齐 (Strategic Planning & Alignment)

ChatGPT 帮助制定前瞻性目标、资源分配和与组织战略的叙述对齐。

| 使用场景 | 提示词 |
|---------|--------|
| **起草季度目标** | Draft clear and measurable quarterly goals for my team. Here is the business context, company objectives, and recent performance: [insert context]. Return 3 Objectives with 3-4 Key Results each, in a simple bullet format.<br><br>**中文版**：为我的团队起草清晰可衡量的季度目标。这是业务背景、公司目标和近期绩效：[插入背景]。返回3个目标，每个3-4个关键结果，以简单的要点格式呈现。 |
| **高管更新谈话要点** | I need to brief my VP on team progress. Based on this weekly summary: [insert notes], generate concise talking points grouped into achievements, blockers, and asks.<br><br>**中文版**：我需要向我的 VP 简报团队进展。基于此每周摘要：[插入笔记]，生成按成就、障碍和请求分组的简明谈话要点。 |
| **进行技能差距分析** | I'm trying to assess skill gaps on my team. Here's our current skill matrix and desired future state: [insert info]. Identify key gaps and suggest training or hiring solutions. Return findings in a short table.<br><br>**中文版**：我正在评估团队的技能差距。这是我们当前的技能矩阵和期望的未来状态：[插入信息]。识别关键差距并建议培训或招聘解决方案。在简短表格中返回发现。 |
| **规划招聘路线图** | I need to plan hiring needs for the next two quarters. Here's our current team structure and projected growth: [insert info]. Suggest a phased hiring plan with rationale for each role and proposed timing.<br><br>**中文版**：我需要规划接下来两个季度的招聘需求。这是我们当前团队结构和预期增长：[插入信息]。建议分阶段招聘计划，为每个角色提供理由和提议时间。 |
| **转型后重塑目标** | We just experienced a strategic pivot. Here's what changed: [insert details]. Help me reframe our team's goals and narrative to align with the new direction. Provide 2-3 talking points and a revised team goal statement.<br><br>**中文版**：我们刚刚经历了战略转型。这是变化：[插入详情]。帮助我重塑团队的目标和叙述以与新方向对齐。提供2-3个谈话要点和修订的团队目标声明。 |

---

## 二、管理辅导与绩效赋能 (Managerial Coaching & Performance Enablement)

ChatGPT 支持管理者指导反馈、发展对话和冲突解决。

| 使用场景 | 提示词 |
|---------|--------|
| **创建1:1会议模板** | Draft a 1:1 meeting template for my direct reports. I want it to include check-ins on progress, roadblocks, career growth, and feedback. Format it as a bulleted agenda with guiding questions.<br><br>**中文版**：为我的直属下属起草1:1会议模板。我希望包括进展检查、障碍、职业发展和反馈。格式化为带引导性问题的要点议程。 |
| **改善反馈表达** | I want to give constructive feedback to a report who is underperforming. The issue is [insert behavior]. Suggest 2-3 ways to phrase it constructively, with pros and cons of each approach.<br><br>**中文版**：我想给表现不佳的下属提供建设性反馈。问题是[插入行为]。建议2-3种建设性表达方式，每种方法的利弊。 |
| **准备困难对话** | I have a difficult conversation coming up with a team member about [insert issue]. Help me think through what to say, how to open, and what questions to ask. Return a 3-part conversation guide.<br><br>**中文版**：我即将与团队成员进行关于[插入问题]的困难对话。帮助我思考该说什么、如何开场以及问什么问题。返回3部分对话指南。 |
| **解决跨团队冲突** | I'm dealing with a conflict between my team and another function. Here's a summary of the tension and recent incidents: [insert info]. Suggest root causes and a 3-step mediation approach I can try.<br><br>**中文版**：我正在处理我的团队与另一个部门之间的冲突。这是紧张局势和近期事件的摘要：[插入信息]。建议根本原因和我可以尝试的3步调解方法。 |

---

## 三、团队分析与健康诊断 (Team Analytics & Health Diagnostics)

ChatGPT 分析定量和定性数据以发现工作负荷平衡、能力差距、绩效趋势和整体团队健康状况。

| 使用场景 | 提示词 |
|---------|--------|
| **从工作时数识别倦怠风险** | Based on this timesheet data (weekly hours logged per person), flag any early signs of burnout risk. Use a threshold of >45 hours for 2+ weeks. Return a summary of flagged employees and trends in average hours.<br><br>**中文版**：基于此时间表数据（每人每周记录的小时数），标记任何倦怠风险的早期迹象。使用2周以上>45小时的阈值。返回标记员工的摘要和平均小时数趋势。 |
| **分析工作负荷分配** | I have a CSV that shows task assignments and completion times per team member for the last 4 weeks. Analyze workload distribution across the team—identify who may be overburdened or underutilized, and summarize in a short paragraph with a chart.<br><br>**中文版**：我有一个 CSV，显示过去4周每个团队成员的任务分配和完成时间。分析团队的工作负荷分配——识别谁可能负担过重或利用不足，并在简短段落中用图表总结。 |
| **诊断团队健康问题** | I'm noticing signs of disengagement or dysfunction on my team. Based on this description of recent behavior and team dynamics: [insert description], what are the likely causes and what should I do next? Provide a 3-part action plan.<br><br>**中文版**：我注意到团队出现脱离或功能失调的迹象。基于此近期行为和团队动态的描述：[插入描述]，可能的原因是什么，我下一步该做什么？提供3部分行动计划。 |

---

## 四、人才研究与基准 (People & Talent Research & Benchmarking)

ChatGPT 进行外部研究以发现基准、循证实践和比较洞察，帮助加强计划并提升参与度举措。**使用深度研究和网络搜索获取更多实时洞察。**

| 使用场景 | 提示词 |
|---------|--------|
| **混合参与最佳实践** | I lead a hybrid team in [insert industry]. Research effective engagement and collaboration practices from the last 2 years. Focus on techniques proven to improve team trust, reduce burnout, and sustain productivity. Provide a top 5 list with supporting evidence and links.<br><br>**中文版**：我领导[插入行业]的一个混合团队。研究过去2年有效的参与和协作实践。专注于已被证明能改善团队信任、减少倦怠和维持生产力的技术。提供前5名列表及支持证据和链接。 |
| **管理者与IC比率基准** | I'm a [insert role, e.g. Senior Engineering Manager] at a [insert company type, e.g., 500-person SaaS company]. I want to benchmark manager-to-IC ratios across similar tech firms. Focus on industry norms, variations by team type (engineering, product, etc.), and recommendations for scaling. Provide citations and a comparison table.<br><br>**中文版**：我是一家[插入公司类型，例如：500人 SaaS 公司]的[插入角色，例如：高级工程经理]。我想对标类似科技公司的管理者与IC比率。关注行业标准、团队类型差异（工程、产品等）和扩展建议。提供引用和比较表格。 |
| **研究有效技能提升计划** | I'm designing an upskilling program for a [insert team type, e.g., customer support team]. Find case studies or frameworks from companies that have implemented successful internal training programs. Include how they measured success, duration, and tools used. Summarize in 3–4 paragraphs with links.<br><br>**中文版**：我正在为[插入团队类型，例如：客户支持团队]设计技能提升计划。查找实施成功内部培训计划的公司的案例研究或框架。包括他们如何衡量成功、持续时间和使用的工具。用链接在3-4段中总结。 |
| **比较DEI策略示例** | I'm helping shape our team's DEI goals. Research how leading companies in [insert industry] structure their DEI initiatives at the team level. Include examples of KPIs, training, and rituals. Return a comparison table with links.<br><br>**中文版**：我正在帮助塑造团队的 DEI 目标。研究[插入行业]的领先公司如何在团队层面构建 DEI 计划。包括 KPI、培训和仪式的示例。返回带链接的比较表格。 |
| **了解倦怠风险和缓解** | I'm seeing signs of burnout on my team. Research recent studies or expert guidance on recognizing burnout in knowledge workers and preventing escalation. Summarize key risk factors and recommend a 3-part action plan with citations.<br><br>**中文版**：我看到团队出现倦怠迹象。研究最近的研究或专家指导，了解知识工作者倦怠的识别和防止升级。总结关键风险因素并推荐带引用的3部分行动计划。 |

---

## 五、团队文化与视觉沟通 (Team Culture & Visual Communication)

ChatGPT 创建引人入胜的视觉隐喻和工件，以传达团队文化、优先事项和变革旅程。

| 使用场景 | 提示词 |
|---------|--------|
| **描绘团队成长旅程** | Design a visual metaphor for a team's growth journey over a year. Include representations of challenges, milestones, and collaboration. Style should be inspiring, like a timeline or path through a landscape.<br><br>**中文版**：为团队一年来的成长旅程设计视觉隐喻。包括挑战、里程碑和协作的表示。风格应该是鼓舞人心的，如时间线或穿越风景的路径。 |
| **可视化总结团队文化** | Design an image that represents our team culture. Our values are [insert 3–5 values, e.g. curiosity, impact, accountability]. Use icons or illustrations to match each value, and organize in a clean layout suitable for a wiki or mural board.<br><br>**中文版**：设计代表我们团队文化的图像。我们的价值观是[插入3-5个价值观，例如：好奇心、影响力、问责制]。使用图标或插图匹配每个价值观，并以适合 wiki 或 mural board 的整洁布局组织。 |
| **展示季度重点领域** | Create a visual dashboard or poster that shows our team's three strategic priorities this quarter: [insert priorities]. Make it visually engaging and easy to present in an all-hands slide.<br><br>**中文版**：创建可视化仪表板或海报，展示我们团队本季度的三个战略优先事项：[插入优先事项]。使其视觉上吸引人且易于在全员幻灯片中展示。 |

---

## 使用建议

### 推荐工具
- **深度研究**：用于人才研究和基准
- **网络搜索**：获取实时管理洞察

### 最佳实践
1. 将方括号 `[...]` 中的内容替换为具体信息
2. 定期更新技能差距分析
3. 保留成功的1:1会议模板
4. 主动识别倦怠风险
5. 根据团队特点调整管理风格

---

*文档生成时间：2025年8月*
*原文链接：https://academy.openai.com/public/clubs/work-users-ynjqu/resources/use-cases-for-managers*
