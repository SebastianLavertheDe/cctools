# ChatGPT for Customer Success - 客户成功团队提示词集合

> 来源：OpenAI Academy
> 标题：ChatGPT for customer success
> 描述：为客户成功团队提供入职策略、竞争研究、客户规划、数据分析和视觉沟通等用例
> 最后更新：2025年8月12日

## 概述

客户成功团队深切关注产品采用、客户留存和长期价值，通常在产品功能和实际成果之间架起桥梁。ChatGPT 可以通过加速研究、起草沟通内容、组织 QBR（季度业务回顾）甚至发掘产品洞察来提供帮助，从而使他们能够花更多时间推动有意义的成果。

---

## 一、客户入职与生命周期策略 (Onboarding & Lifecycle Strategy)

ChatGPT 可以通过模板、反馈综合、研究和主动行动手册来起草客户入职和生命周期留存策略。

| 使用场景 | 提示词 |
|---------|--------|
| **创建入职计划模板** | Create a reusable onboarding plan template for [type of customer]. Reference typical timelines, milestones, and stakeholder alignment needs. Format as a week-by-week table with task owners and goals.<br><br>**中文版**：为[客户类型]创建可重复使用的入职计划模板。参考典型时间线、里程碑和利益相关者对齐需求。格式化为逐周表格，包含任务负责人和目标。 |
| **总结入职反馈** | Summarize onboarding feedback from our last 10 customers in [segment]. Use these shared notes and survey answers. Output a short paragraph per theme: wins, blockers, suggestions.<br><br>**中文版**：总结[细分领域]最近 10 位客户的入职反馈。使用这些共享笔记和调查答案。每个主题输出一段简短段落：成功点、障碍、建议。 |
| **识别高接触入职最佳实践** | Research how leading B2B companies structure high-touch onboarding journeys. Focus on companies with $1M+ ACV and hybrid onboarding models. Include sources and structure the output as a bulleted summary of key tactics with references.<br><br>**中文版**：研究领先的 B2B 公司如何构建高接触式入职旅程。重点关注 ACV 超过 100 万美元和混合入职模式的公司。包括来源，并将输出构建为带参考的关键策略要点总结。 |
| **建议主动行动手册** | Recommend 3 proactive outreach playbooks for at-risk customers in [industry/segment]. Use trends from recent churn, feature inactivity, and low engagement. Output should include: goal, trigger, CTA, and timing.<br><br>**中文版**：为[行业/细分领域]的高风险客户推荐 3 个主动外展行动手册。使用最近流失、功能不活跃和低参与度的趋势。输出应包括：目标、触发条件、行动号召和时机。 |
| **头脑风暴留存激励** | Suggest creative retention strategies for accounts likely to downgrade in [industry]. Use trends in usage and renewal hesitations we've seen. Output 5 tested and 5 novel ideas with pros/cons.<br><br>**中文版**：为[行业]中可能降级的账户建议有创意的留存策略。使用我们观察到的使用和续约犹豫趋势。输出 5 个已验证的想法和 5 个新颖的想法，并说明利弊。 |

---

## 二、竞争与基准研究 (Competitive & Benchmark Research)

ChatGPT 进行外部研究，以基准化组织结构、指标、工具和竞争成功计划策略，为明智决策提供支持。**使用深度研究（Deep Research）获得更全面的结果。**

| 使用场景 | 提示词 |
|---------|--------|
| **基准化 CS 组织结构** | Benchmark the CS org structure for companies like ours in [industry, size]. Focus on roles per customer segment and ratio to revenue. Output as a comparison table with notes on headcount ratios.<br><br>**中文版**：基准化我们[行业、规模]类似公司的 CS 组织结构。重点关注每个客户细分领域的角色和收入比例。输出为比较表格，并附上人员配比说明。 |
| **按行业基准化成功指标** | Research top 3 success metrics used for customer health scoring in the [industry] sector. Include CSAT, NRR, usage frequency, or other emerging benchmarks. Output as a table comparing metric, source, and benchmark value with citations.<br><br>**中文版**：研究[行业]领域用于客户健康评分的前 3 项成功指标。包括 CSAT、NRR、使用频率或其他新兴基准。输出为比较指标、来源和基准值的表格，并附引用。 |
| **评估 CS 工具栈** | Research typical Customer Success tech stacks for companies in early-stage, growth-stage, and enterprise. Include categories (e.g., CRM, Success Platform, Analytics). Output a comparison chart with examples and usage notes.<br><br>**中文版**：研究早期、成长期和企业阶段公司的典型客户成功技术栈。包括类别（例如：CRM、成功平台、分析工具）。输出带有示例和使用说明的比较图表。 |
| **竞争赋能总结** | Research how competitors are supporting enterprise customers post-sale in [industry]. Include examples of success resources, team structure, and onboarding formats. Output as a table comparing 3 competitors with pros/cons per tactic.<br><br>**中文版**：研究竞争对手如何在[行业]售后支持企业客户。包括成功资源、团队结构和入职格式的示例。输出为比较 3 个竞争对手的表格，并说明每种策略的利弊。 |
| **创建 CS 计划竞争比较** | Research what customer success programs look like at our top 3 competitors. Focus on onboarding, health tracking, and expansion strategies. Output a comparison matrix.<br><br>**中文版**：研究我们的前 3 大竞争对手的客户成功计划是什么样的。重点关注入职、健康跟踪和扩张策略。输出比较矩阵。 |

---

## 三、客户规划与续约准备 (Account Planning & Renewal Prep)

ChatGPT 指导高管沟通、QBR、续约准备和战略客户规划的结构化准备。**使用 Canvas 进行实时编辑。**

| 使用场景 | 提示词 |
|---------|--------|
| **起草高管邮件更新** | Write a weekly update email for [executive stakeholder at customer]. Use these internal notes from this week's call and usage metrics: [paste here]. Output should be a short, polished email with 3 bullets.<br><br>**中文版**：为[客户高管利益相关者]写每周更新邮件。使用本周通话和这些使用指标的内部笔记：[在此粘贴]。输出应为简短、润色过的邮件，包含 3 个要点。 |
| **起草 QBR 讨论要点** | Summarize the top wins, risks, and product usage highlights for [Customer Name] ahead of our QBR. Use their latest health score, usage trends, and support ticket history. Format as a bulleted prep doc for internal review.<br><br>**中文版**：在我们的 QBR 之前总结[客户名称]的最大胜利、风险和产品使用亮点。使用他们最新的健康评分、使用趋势和支持工单历史。格式化为内部审查的要点准备文档。 |
| **准备续约电话** | Create a renewal call prep checklist for [Customer Name]. Include contract terms, current usage, known risks, and upsell potential. Output as a bulleted checklist.<br><br>**中文版**：为[客户名称]创建续约电话准备清单。包括合同条款、当前使用情况、已知风险和增购潜力。输出为要点清单。 |
| **创建客户计划摘要** | Draft a 1-pager account plan for [Customer Name]. Use notes from our last 2 calls + contract info + goals: [paste here]. Output should be formatted as goals, blockers, actions, and renewals.<br><br>**中文版**：为[客户名称]起草一页客户计划。使用我们最近 2 次通话的笔记 + 合同信息 + 目标：[在此粘贴]。输出应格式化为目标、障碍、行动和续约。 |
| **概述续约风险摘要** | Draft a renewal risk summary for [Customer Name] ahead of our internal forecast call. Include their renewal date, usage trend, sentiment, and contract notes. Output should be a paragraph summary + 1-line recommendation.<br><br>**中文版**：在我们的内部预测会议之前为[客户名称]起草续约风险摘要。包括他们的续约日期、使用趋势、情绪和合同说明。输出应为一段摘要 + 一行建议。 |

---

## 四、数据与健康分析 (Data & Health Analysis)

分析定量和定性客户信号，生成指标定义、绩效洞察、风险检测和评分框架。**为经常完成的分析任务创建自定义 GPT。**

| 使用场景 | 提示词 |
|---------|--------|
| **按细分领域概述成功指标** | Outline a draft list of success metrics for [segment] customers. Include adoption goals, engagement targets, and renewal benchmarks. Format as a 2-column table: Metric | Definition.<br><br>**中文版**：概述[细分领域]客户的成功指标草稿列表。包括采用目标、参与度目标和续约基准。格式化为 2 列表格：指标 | 定义。 |
| **评估 CSAT 分数分布** | Review this CSAT survey data from Q2. Calculate overall average, identify outlier scores, and summarize feedback themes if available. Output as a short summary with key stats and top positive/negative feedback examples.<br><br>**中文版**：审查 Q2 的 CSAT 调查数据。计算总体平均值，识别异常分数，并在可用时总结反馈主题。输出为简短摘要，包含关键统计数据和顶级正面/负面反馈示例。 |
| **分析支持工单趋势** | Examine this export of support tickets from the last quarter. Identify the top 5 recurring issues and provide a short summary of root causes. Output should include a ranked list with issue, frequency, and potential CS actions.<br><br>**中文版**：检查上个季度支持工单的导出数据。识别前 5 个重复出现的问题，并提供根本原因的简短摘要。输出应包括带问题、频率和潜在 CS 行动的排序列表。 |
| **发现流失早期迹象** | Review this customer usage data from the past 90 days. Identify any customers who may be at risk of churning based on usage drop, login frequency, or support interactions. Summarize the findings in a table with columns: Customer Name | Risk Factor | Notes.<br><br>**中文版**：审查过去 90 天的客户使用数据。根据使用量下降、登录频率或支持交互识别任何可能流失风险的客户。在表格中总结发现结果，列包括：客户名称 | 风险因素 | 说明。 |
| **标准化客户健康评分** | Build a draft health scoring rubric for [segment or region]. Use inputs like usage %, NPS, renewal status, and ticket volume. Output as a table with scoring ranges, weights, and color indicators.<br><br>**中文版**：为[细分领域或区域]构建健康评分草稿标准。使用输入如使用百分比、NPS、续约状态和工单量。输出为带评分范围、权重和颜色指示器的表格。 |

---

## 五、视觉与图表设计 (Visual & Diagram Design)

ChatGPT 创建清晰、演示就绪的视觉图表和模型，用于传达旅程、流程、成熟阶段和健康指标。

| 使用场景 | 提示词 |
|---------|--------|
| **设计客户健康评分模型** | Design a visual mock-up of a color-coded health score gauge for customers. Include Low, Medium, High ranges with suggested numerical ranges and icons. Style: dashboard-style, clean lines, professional.<br><br>**中文版**：为客户设计颜色编码的健康评分仪表板可视化模型。包括低、中、高范围以及建议的数值范围和图标。风格：仪表板风格、线条简洁、专业。 |
| **可视化客户旅程地图** | Turn this outline of customer lifecycle stages into a visual journey map. Use the stages and pain points listed here: [paste text]. Output as a labeled diagram with 5 lifecycle stages.<br><br>**中文版**：将此客户生命周期阶段大纲转换为可视化旅程地图。使用此处列出的阶段和痛点：[粘贴文本]。输出为带 5 个生命周期阶段的标注图表。 |
| **说明升级流程图** | Create a diagram that illustrates the internal escalation process from CSM to Support to Engineering. Include 3 levels of severity and labeled handoff points. Style: flowchart format, minimal colors, ready for internal wiki.<br><br>**中文版**：创建一个图表，说明从 CSM 到支持再到工程的内部升级流程。包括 3 个严重性级别和标注的交接点。风格：流程图格式、最少颜色、适合内部 wiki。 |
| **构建视觉客户成熟度模型** | Create an image that visualizes a 4-stage customer maturity model for a SaaS platform. Each stage should have a title, key behavior pattern, and suggested CS touchpoint. Style: professional, clean, slide-ready.<br><br>**中文版**：创建一个图像，可视化 SaaS 平台的 4 阶段客户成熟度模型。每个阶段应具有标题、关键行为模式和建议的 CS 接触点。风格：专业、简洁、适合幻灯片演示。 |

---

## 使用建议

### 推荐工具
- **Canvas**：用于实时编辑和优化文档
- **Custom GPT**：为经常完成的分析任务创建可重复的流程
- **Deep Research**：用于更全面的竞争和基准研究

### 最佳实践
1. 将方括号 `[...]` 中的内容替换为具体信息
2. 根据客户细分和行业特征定制提示词
3. 定期更新健康评分标准和指标定义
4. 使用视觉工具提升沟通效果
5. 保留成功模板以供团队复用

### 关键关注领域
- **客户采用** (Adoption)
- **客户留存** (Retention)
- **长期价值** (Long-term Value)
- **产品与成果对齐** (Product-Outcome Alignment)

---

*文档生成时间：2025年8月*
*原文链接：https://academy.openai.com/public/clubs/work-users-ynjqu/resources/use-cases-customer-success*
